/** Single source of truth for WGSL uniform struct layouts. */
interface UniformLayout<T extends string> {
    /** WGSL struct body text (indented field lines) */
    fields: string;
    /** Byte offset of each field (keyed by field name) */
    offsets: Record<T, number>;
    /** Total struct size in bytes (rounded to max alignment) */
    size: number;
}
/** Per-level scale table length; datasets with more levels are rejected at load. */
export declare const MAX_LOD_LEVELS = 12;
export declare const COMPUTE_UNIFORMS: UniformLayout<"inverseViewProj" | "cameraPos" | "useIndirection" | "datasetSize" | "renderMode" | "normalizedSize" | "isoValue" | "screenSize" | "frameIndex" | "jitter" | "windowCenter" | "windowWidth" | "floatMin" | "floatMax" | "clipMin" | "densityScale" | "clipMax" | "numChannels" | "channelColors" | "channelWindowCenter" | "channelWindowWidth" | "lodScales" | "shading" | "gradientOpacity" | "orthographic" | "pickPixel" | "background">;
/** Label layers shown at once; each has a row of entries and a slot in LABEL_UNIFORMS.layers. */
export declare const MAX_LABEL_LAYERS = 8;
export declare const LABEL_UNIFORMS: UniformLayout<"layerCount" | "atlasSlots" | "atlasGrid" | "poolGrid" | "layers">;
export declare const SLICE_UNIFORMS: UniformLayout<"datasetSize" | "normalizedSize" | "windowCenter" | "windowWidth" | "floatMin" | "floatMax" | "numChannels" | "channelColors" | "channelWindowCenter" | "channelWindowWidth" | "lodScales" | "mvp" | "slicePositions" | "sliceXEnabled" | "sliceYEnabled" | "sliceZEnabled" | "lodDebug">;
export {};
