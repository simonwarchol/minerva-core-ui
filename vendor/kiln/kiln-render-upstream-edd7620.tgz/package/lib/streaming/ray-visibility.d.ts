/**
 * Ray-guided streaming (on by default, off with `?rayguide=0`): which finest-level brick cells
 * the raycaster actually entered recently. The compute shader sets one bit per
 * cell a ray enters before it terminates; the renderer reads that bitset back
 * every few frames and reports it here.
 *
 * Age is counted in rendered frames, not wall time: when the image has converged
 * the renderer stops, no readbacks arrive, and what was visible stays visible.
 * Frames rather than readbacks, so the window is the same whether a readback
 * covers one frame (TAA off) or several.
 */
import type { Vec3 } from '../core/pyramid.js';
export declare class RayVisibility {
    private readonly grid;
    /** Frames a cell stays visible after it was last seen, so refinement can't thrash the cache. */
    private readonly holdFrames;
    /** Frame count at the readback in which each cell was last seen (0 = never). */
    private readonly lastSeen;
    private frame;
    constructor(grid: Vec3, 
    /** Frames a cell stays visible after it was last seen, so refinement can't thrash the cache. */
    holdFrames?: number);
    /** Number of u32 words the shader's bitset needs for this grid. */
    static wordCount(grid: Vec3): number;
    /** True once at least one readback arrived since construction or the last reset. */
    get ready(): boolean;
    /** Fold one readback in: bit i set ⇔ a ray entered cell i during the `frames` frames it covers. */
    report(bits: Uint32Array, frames?: number): void;
    /** Forget everything, e.g. when no rays are marched (slice mode). */
    reset(): void;
    /** Whether any cell of the box [base, base + span) was seen within the hold window. */
    anySeen(base: Vec3, span: Vec3): boolean;
}
