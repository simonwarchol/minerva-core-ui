/**
 * Placeholder data for a partially loaded brick: an ancestor brick's region,
 * nearest-neighbour resampled into the child's physical layout (ghost border
 * included). A channel that has not arrived yet then shows exactly the coarse
 * data it showed before the child was committed, instead of zeros.
 */
import type { BrickData } from '../data/data-provider.js';
type Vec3 = [number, number, number];
/**
 * @param parent   ancestor brick data, `physSize³` voxels
 * @param child    child brick index at its level
 * @param ancestor ancestor brick index at its level
 * @param ratio    child-level voxels per ancestor-level voxel, per axis (power of two)
 */
export declare function upsampleFromAncestor(parent: BrickData, child: Vec3, ancestor: Vec3, ratio: Vec3, logicalSize?: number, physSize?: number): BrickData;
export {};
