/**
 * StreamingManager - Resident set manager for brick streaming. Selects visible
 * bricks by frustum/LOD, queues priority loads, and cancels stale requests.
 */
import { type ViewParams } from '../core/view.js';
import type { VolumeResources } from '../core/volume-resources.js';
import type { DataProvider, VolumeMetadata } from '../data/data-provider.js';
import { AtlasSlot } from './atlas-allocator.js';
import type { DatasetConfig } from '../core/config.js';
import type { PipelineTimings } from '../data/data-provider.js';
import type { BrickMilestones } from '../core/milestones.js';
/** One view, or one per pane of a multi-view layout. */
type ViewInput = ViewParams | readonly ViewParams[];
export interface BrickRequest {
    lod: number;
    bx: number;
    by: number;
    bz: number;
    distance: number;
    key: string;
}
export interface LoadedBrickInfo {
    slot: AtlasSlot;
    slotIndex: number;
}
export interface StreamingStats {
    desiredCount: number;
    loadedCount: number;
    pendingCount: number;
    cancelledCount: number;
    atlasUsage: number;
    atlasCapacity: number;
    totalBytesDownloaded: number;
    bytesPerSecond: number;
    requestCount: number;
    evictedCount: number;
    allocationsRefused: number;
    pipelineTimings: PipelineTimings;
    bricksDispatched: number;
    bricksCommitted: number;
    bricksCancelled: number;
    bricksDiscarded: number;
    bricksFailed: number;
    avgBrickLatencyMs: number;
    rayCulledCount: number;
}
export declare class StreamingManager {
    private resources;
    private onResetAccumulation;
    private dataProvider;
    private metadata;
    private device;
    private config;
    private loadedBricks;
    private pinnedBricks;
    private emptyBricks;
    private brickCache;
    baseLodLoaded: boolean;
    /** Base-load milestones (performance.now() timestamps); reset by clear(). */
    readonly milestones: BrickMilestones;
    private desiredKeys;
    private loadQueue;
    private inFlightRequests;
    private generation;
    private baseLoadAbort;
    private disposed;
    private inFlightStaleTime;
    private readonly CANCEL_GRACE_MS;
    private maxConcurrentRequests;
    private onBaseLodLoaded;
    private baseHistograms;
    private onRangesDerived;
    private baseLodPending;
    private frameCount;
    private resetAccumulationTimer;
    private firstPendingResetAt;
    private contentVersionCounter;
    private uploadAvg;
    private bricksDispatched;
    private bricksCommitted;
    private bricksCancelled;
    private bricksDiscarded;
    private bricksFailed;
    private brickLatencyAvg;
    private dispatchTimestamps;
    maxPixelError: number;
    private projectionFactor;
    private maxDesiredBricks;
    private allocationStalled;
    private zeroBricks;
    private dirtyChannels;
    private slotChannels;
    private visibleMask;
    private providerStatsCoverVisibleChannels;
    private fillAbort;
    private pendingVisibleBits;
    private fillPending;
    private lastStats;
    private rayGuided;
    private rayViews;
    private lastUpdateFrame;
    private updateInterval;
    private lastCameraPos;
    private cameraStillFrames;
    private cameraMovementThreshold;
    private cameraStillThreshold;
    private readonly maxLod;
    private readonly levelsByLod;
    constructor(resources: VolumeResources, dataProvider: DataProvider, metadata: VolumeMetadata, device: GPUDevice, config: DatasetConfig, onResetAccumulation: () => void, visibleChannels?: number);
    /** Called when the base LOD has loaded, and again when a channel shown later has filled in. */
    setBaseLodLoadedCallback(callback: () => void): void;
    /**
     * Value distribution of one channel over the loaded base level, in shader space (0–1,
     * the units of channel windows). Null until the channel's base bricks have loaded.
     */
    getChannelHistogram(channel: number, bins?: number): Uint32Array | null;
    private histogramBrick;
    /** Set callback for when base LOD derives float/channel ranges */
    setRangesDerivedCallback(callback: (opts: {
        dataRange?: [number, number];
        channelRanges?: Array<{
            min: number;
            max: number;
        }>;
    }) => void): void;
    /** Lazily create (and cache) a physical brick of zeros as the canvas stores them */
    private getZeroBrick;
    /** CPU cache key by source identity (channel + timepoint), so slots can be remapped
     *  and timepoints revisited without re-downloading. */
    private cacheKey;
    /** Channels to fetch for a brick: the visible ones (never empty). */
    private channelsToLoad;
    /** Write one channel of a slot (null = zeros) and keep the per-slot channel bits in sync. */
    private writeSlotChannel;
    /** Channel regions of a slot that don't hold the baseline. Fresh texels are all-zero bits,
     *  which is the baseline only for unorm atlases, so on r16float every unwritten region counts. */
    private dirtyBits;
    /** Zero every channel region of a freshly (re)allocated slot that still holds older data. */
    private zeroStaleChannels;
    /** Renderer-visible channel bitmask. Newly visible channels are fetched for every resident
     *  brick that lacks them; hiding costs nothing. */
    setVisibleChannels(mask: number): void;
    private fillMissingChannels;
    /** Load and pin the coarsest LOD level with bounded concurrency. */
    private loadBaseLod;
    /**
     * Main update loop - call every frame
     * Returns true if any work was done
     */
    update(view: ViewInput): void;
    /** Whether any view's camera moved significantly, or a view was added or removed. */
    private camerasMoved;
    /** Ray-guided brick selection: only bricks that rays actually reach get refined. */
    enableRayGuidance(): void;
    /** Ray guidance state of view `view`; null when guidance is off. */
    private rayView;
    /** One visibility readback from view `view`'s renderer, covering `frames` frames: bit i set ⇔ a ray entered finest-level cell i. */
    reportRayVisibility(bits: Uint32Array, frames?: number, view?: number): void;
    /** Rays are only marched in the volume modes; slice planes may sample any brick. */
    setRayGuidanceActive(active: boolean, view?: number): void;
    /** Forget the state of view `view`; later views move down one index. */
    removeView(view: number): void;
    /** Whether view `view`'s ray guidance leaves out this brick: below the pinned base level and not reached by its rays lately. */
    private rayCulls;
    /**
     * Force immediate recomputation of desired set
     */
    forceUpdate(view: ViewInput): void;
    /**
     * Clear all state
     */
    /** Abort all work and drop timers; the manager is inert afterwards. GPU resources are owned by VolumeResources. */
    dispose(): void;
    clear(): void;
    /**
     * Re-stream after the provider switched source channels/timepoint (metadata is shared,
     * so the new mapping is already visible here). The old picture stays up: base bricks keep
     * their slots and are overwritten as the new data lands; finer bricks are released and
     * refined again once the new base is complete. `changedChannels` = slot bitmask whose
     * data is stale; the CPU brick cache is keyed by source identity and needs no flush.
     */
    reload(changedChannels: number): void;
    /** Abort every fetch and forget queue, emptiness and milestones; resident slots are untouched. */
    private stopStreaming;
    /** Give a resident brick's slot back (unpinned); the indirection entry is the caller's business. */
    private releaseResident;
    /**
     * Get current stats
     */
    getStats(): StreamingStats;
    /**
     * Compute the desired set of bricks based on camera position and frustum
     * Uses Screen-Space Error (SSE) for LOD selection. With several views it is
     * the union of each view's set, at the nearest distance any view sees a brick.
     */
    private computeDesiredSet;
    private addDesiredBrick;
    /**
     * Process pending load requests (non-blocking)
     */
    private processLoadQueue;
    /**
     * Load a single brick with abort support
     */
    private loadBrick;
    /**
     * Multichannel refinement that shows data as soon as it exists: the brick is
     * committed on its first non-empty channel, channels still in flight get the
     * displayed ancestor's data resampled (no dropout), real data replaces it on
     * arrival. Falls back to an all-channels commit when no placeholder exists.
     */
    private loadBrickProgressive;
    /** The displayed ancestor's data for one channel, resampled into this brick; null if unavailable. */
    private placeholderFor;
    /** Point an evicted brick's region back at its displayed ancestor (or empty / unloaded). */
    private releaseEvicted;
    /** Bumped on every visible content commit (brick upload or empty marker). */
    get contentVersion(): number;
    /** Record a content commit (also label bricks) and schedule the accumulation reset that displays it. */
    notifyContentChanged(): void;
    private scheduleAccumulationReset;
    /** Fire a pending (or immediate) accumulation reset now. */
    private flushAccumulationReset;
    private cancelAccumulationReset;
    private getBrickAABB;
    private getAABBCenter;
    private distance;
    /**
     * Get the world-space size of one voxel at a given LOD level
     * At LOD N, each voxel represents 2^N original voxels
     */
    /** Conservative SSE voxel size at `lod`: the largest voxel among axes that finer levels
     *  still improve (exponent > 0), so an axis stored at native resolution never forces a split. */
    private getVoxelWorldSize;
    /**
     * Find the parent (coarser LOD) brick that covers the same region
     * Used to restore fallback data when evicting a finer LOD brick
     */
    private findParentBrick;
    /** Check if any child brick (one LOD finer) is loaded or in-flight (SSE hysteresis). */
    private hasResidentChildren;
    /** Check if any ancestor brick is known-empty (for eviction fallback). */
    private hasEmptyAncestor;
}
export {};
