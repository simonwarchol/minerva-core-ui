/**
 * Generalised multiscale pyramid: per-level native dims, per-axis downsampling
 * exponent relative to level 0, physical spacing and origin. Built from OME-Zarr
 * transforms (or inferred from dims) and validated for the 1×/2× steps Kiln supports.
 */
export type Vec3 = [number, number, number];
/** Temporary rollout switch: Kiln's historical uniform 2:1 model vs. per-axis factors from metadata. */
export type PyramidPolicy = 'legacy' | 'native';
export interface PyramidLevel {
    lod: number;
    /** Native voxel dimensions [x, y, z]. */
    dims: Vec3;
    /** log2 of the downsampling factor relative to level 0, per axis. */
    exponent: Vec3;
    /** Physical voxel spacing per axis. */
    spacing: Vec3;
    /** Physical position of voxel (0,0,0) per axis, after group transforms. */
    origin: Vec3;
}
/** One level as read from metadata, all vectors in [x, y, z] order. */
export interface PyramidLevelInput {
    dims: Vec3;
    scale?: Vec3;
    translation?: Vec3;
}
export interface PyramidBuild {
    levels: PyramidLevel[];
    /** Human-readable reasons the layout is unsupported; empty when valid. */
    issues: string[];
}
/** Build and validate a pyramid; group-level transforms compose after per-level ones. */
export declare function buildPyramid(inputs: PyramidLevelInput[], groupScale?: Vec3, groupTranslation?: Vec3): PyramidBuild;
/** Kiln's historical model: every level halves every axis, dims = ceil(dims0 / 2^lod), origins ignored. */
export declare function legacyPyramid(dims0: Vec3, spacing0: Vec3, numLevels: number): PyramidLevel[];
/** Finest-grid voxels covered by one logical brick of this level, per axis. */
export declare function levelSpan(level: PyramidLevel, brickSize: number): Vec3;
