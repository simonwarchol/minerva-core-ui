/** Load milestones as performance.now() timestamps (ms since navigation start); null until reached. */
export interface LoadMilestones {
    /** KilnEngine.create() entered — separates a dataset open from page startup. */
    datasetOpenStart: number;
    /** GPU device available (reported by the host that requested it). */
    deviceReady: number | null;
    metadataReady: number | null;
    /** Renderer, atlas and pipelines constructed. */
    gpuReady: number | null;
    firstBrickDecoded: number | null;
    firstAtlasCommit: number | null;
    baseCoverage10: number | null;
    baseCoverage50: number | null;
    baseCoverage90: number | null;
    /** Every base brick has its channel 0 resolved — a complete one-channel image (channel-major loads). */
    baseChannel0Complete: number | null;
    baseComplete: number | null;
    /** First frame submitted after resident data was committed; not proof of presentation. */
    firstContentSubmit: number | null;
    /** Presentation proxy: first animation-frame callback after firstContentSubmit. */
    firstContentFrame: number | null;
}
export type BrickMilestones = Pick<LoadMilestones, 'firstBrickDecoded' | 'firstAtlasCommit' | 'baseCoverage10' | 'baseCoverage50' | 'baseCoverage90' | 'baseChannel0Complete' | 'baseComplete'>;
export declare function createBrickMilestones(): BrickMilestones;
/** Stamp the coverage milestones that `resolved / total` base bricks have just crossed. */
export declare function stampBaseCoverage(m: BrickMilestones, resolved: number, total: number, now: number): void;
