/**
 * Volume Renderer using proxy box geometry
 */
import { type ViewParams } from './view.js';
import { TransferFunction } from './transfer-function.js';
import { VolumeResources } from './volume-resources.js';
import type { DatasetConfig } from './config.js';
import type { LabelGpu } from '../labels/label-gpu.js';
export declare const SOFT_RESET_FRAMES = 4;
export type VolumeRenderMode = 'dvr' | 'mip' | 'iso' | 'lod' | 'slice' | 'slice-lod';
export declare class Renderer {
    /** Label layers drawn over the volume (shared by every view) */
    private readonly labels;
    /** Mark the brick cells rays enter and read them back for ray-guided streaming */
    readonly rayGuided: boolean;
    private device;
    /** Volume atlas textures, indirection table, and slot allocator */
    readonly resources: VolumeResources;
    get numChannels(): number;
    get canvas(): import("./volume.js").VolumeCanvas;
    get canvases(): import("./volume.js").VolumeCanvas[];
    useIndirection: boolean;
    showWireframe: boolean;
    densityScale: number;
    shading: number;
    gradientOpacity: number;
    showAxis: boolean;
    background: Float32Array<ArrayBuffer>;
    enableJitter: boolean;
    enableTAA: boolean;
    softReset: boolean;
    volumeRenderMode: VolumeRenderMode;
    isoValue: number;
    windowCenter: number;
    windowWidth: number;
    floatMin: number;
    floatMax: number;
    texelScale: number;
    texelBias: number;
    clipMin: Float32Array<ArrayBuffer>;
    clipMax: Float32Array<ArrayBuffer>;
    sliceX: number;
    sliceY: number;
    sliceZ: number;
    showSliceX: boolean;
    showSliceY: boolean;
    showSliceZ: boolean;
    renderScale: number;
    private wireframePipeline;
    private axisPipeline;
    private slicePipeline;
    private sliceBindGroup;
    private sliceUniformBuffer;
    private computePipeline;
    private pickPipeline;
    private pickBindGroup;
    private readonly pickReadback;
    private pickPending;
    private pickBusy;
    /** LabelGpu.version the bind groups were built with */
    private labelVersion;
    private readonly lastCameraPos;
    private lastOrthographic;
    private hasRendered;
    private blitPipeline;
    private computeUniformBuffer;
    private readonly rayVisitedBuffer;
    private readonly rayReadback;
    private rayReadbackBusy;
    private rayFramesPending;
    /** Frames covered by the copy currently being read back. */
    private rayReadbackFrames;
    /** Called with each visibility readback (bit i ⇔ a ray entered finest-level cell i) and the frames it covers. */
    onRayVisibility?: (bits: Uint32Array, frames: number) => void;
    private accumPipeline;
    private accumUniformBuffer;
    private scaleSets;
    private active;
    private prevVP;
    private wireframeBindGroup;
    private axisBindGroup;
    private vertexBuffer;
    private wireframeIndexBuffer;
    private wireframeUniformBuffer;
    private axisVertexBuffer;
    private axisUniformBuffer;
    private depthTexture;
    private depthView;
    private volumeSampler;
    private tfSampler;
    private blitSampler;
    private tfTexture;
    private wireframeIndexCount;
    private screenWidth;
    private screenHeight;
    private frameIndex;
    private disposed;
    private readonly config;
    readonly channelColors: Float32Array<ArrayBuffer>;
    readonly channelWindowCenter: Float32Array<ArrayBuffer>;
    readonly channelWindowWidth: Float32Array<ArrayBuffer>;
    private readonly vpScratch;
    private readonly invVPScratch;
    private readonly computeUniformScratch;
    private readonly computeUniformView;
    private readonly accumScratch;
    private readonly sliceUniformScratch;
    private readonly sliceUniformView;
    constructor(device: GPUDevice, format: GPUTextureFormat, resources: VolumeResources, config: DatasetConfig, 
    /** Label layers drawn over the volume (shared by every view) */
    labels: LabelGpu, 
    /** Mark the brick cells rays enter and read them back for ray-guided streaming */
    rayGuided?: boolean);
    /** Callback invoked when the scene needs a re-render (parameter change, brick arrival, etc.) */
    onDirty?: () => void;
    /** Signal that the scene changed and needs a re-render (without resetting accumulation) */
    markDirty(): void;
    /** Reset temporal accumulation (call when rendering parameters change) */
    resetAccumulation(): void;
    /**
     * Copy the shared display settings of `src` (everything but the render mode) into this
     * renderer. Returns true if anything changed; the caller then resets accumulation.
     */
    syncLook(src: Renderer): boolean;
    /**
     * Show newly committed bricks. Restarts accumulation, or with `softReset` keeps the
     * history as SOFT_RESET_FRAMES frames: the new data blends in over a few frames instead
     * of the image dropping back to one jittered sample per pixel, which shows as woodgrain.
     */
    bricksCommitted(): void;
    /** Jitter uniform: 0 = off, 1 = seeded by ray direction, 2 = seeded per pixel (`softReset`). */
    get jitterMode(): number;
    /** Whether the image is stable (no further rendering will change the output) */
    private get isSliceMode();
    get isConverged(): boolean;
    /** Set the display color and intensity weight for a channel (0–3). Resets accumulation. */
    setChannelColor(ch: number, r: number, g: number, b: number, a?: number): void;
    /** Set the window center and width for a channel (0–3). Resets accumulation. */
    setChannelWindow(ch: number, center: number, width: number): void;
    /**
     * Set the transfer function and recreate bind groups
     */
    setTransferFunction(tf: TransferFunction): void;
    private recreateVolumeBindGroups;
    resize(width: number, height: number): void;
    prepareScale(scale: number): void;
    /** switch to a pre-allocated scale set */
    activateScale(scale: number): void;
    private buildScaleSet;
    private destroyScaleSet;
    /** Destroy renderer-owned GPU textures and buffers (device, atlas and TF texture are external). */
    dispose(): void;
    private rebuildScaleSetBindGroups;
    /** Pool, entries, palette and styles of the label layers. */
    private labelBindings;
    /**
     * The label record (see LabelGpu.pick) at pixel (x, y) of this view, in output pixels: the
     * front-most drawn label along the ray in volume modes (taken by the next render, so the caller
     * marks the view dirty), the slice plane under the pixel in slice mode. Resolves null when
     * superseded by a newer pick.
     */
    pick(x: number, y: number): Promise<ArrayBuffer | null>;
    /** Slice mode: intersect the pixel's ray with the shown planes on the CPU, then look labels up. */
    private pickSlices;
    /** Finest-level voxel where the pixel's ray first meets a shown slice plane, or null. */
    private slicePlaneVoxel;
    private encodePick;
    private readPick;
    private updateSliceUniforms;
    render(colorView: GPUTextureView, view: ViewParams): void;
    private getRenderModeInt;
    /** Get depth view for external renderers (debug wireframes, etc) */
    getDepthView(): GPUTextureView;
    /** Get view-projection matrix for external renderers */
    getViewProjMatrix(view: ViewParams): Float32Array;
    private renderCompute;
    /** Copy collected visits only when the staging buffer is available. */
    private copyRayVisits;
    /** Map the staging copy without stalling the frame; the next copy waits until it is unmapped. */
    private readRayVisits;
    /** Whether rays are marched (and cells marked) in the current mode; slice planes sample the atlas directly. */
    get marchesRays(): boolean;
}
