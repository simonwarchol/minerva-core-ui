/**
 * Histogram computation utilities for volume data analysis
 */
import type { BitDepth } from '../data/data-provider.js';
/** Counts indexed by the stored voxel value: uint8, uint16, or float16 bit pattern. */
export interface RawHistogram {
    counts: Uint32Array;
    /** Data arrived as Uint8Array (0–255) rather than Uint16Array. */
    is8Bit: boolean;
}
export declare function createRawHistogram(is8Bit: boolean): RawHistogram;
/** Add every voxel of a brick to the raw counts (one increment per voxel, no decoding). */
export declare function accumulateRaw(hist: RawHistogram, data: Uint8Array | Uint16Array): void;
/** Rebin raw counts onto `bins` equal shader-space (0–1) bins. */
export declare function rebinHistogram(raw: RawHistogram, bitDepth: BitDepth, bins?: number, isFloat32?: boolean, floatMin?: number, floatMax?: number, targetFormat?: GPUTextureFormat): Uint32Array;
/**
 * Compute a histogram from volume data arrays. Handles uint8/uint16 directly,
 * float32-as-r16float (with range remapping), and uint16-as-r16float.
 */
export declare function computeHistogram(dataArrays: (Uint8Array | Uint16Array)[], bitDepth: BitDepth, bins?: number, isFloat32?: boolean, floatMin?: number, floatMax?: number, targetFormat?: GPUTextureFormat): Uint32Array;
/**
 * Values at the quantiles `lo` and `hi` (0–1) of float16 voxels, from their raw counts (see
 * accumulateRaw). Exact: every stored value is one of the 65536 bit patterns, so outliers
 * can't coarsen the result. Non-finite values are ignored; null without finite voxels.
 */
export declare function float16Quantiles(counts: Uint32Array, lo: number, hi: number): [number, number] | null;
/** Number of distinct float16 values in [lo, hi]: how finely the atlas resolves that range. */
export declare function float16Levels(lo: number, hi: number): number;
