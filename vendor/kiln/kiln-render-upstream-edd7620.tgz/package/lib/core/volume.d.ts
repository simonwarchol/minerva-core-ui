/**
 * Volume canvas (atlas) and test volume generation
 */
import type { BitDepth, BrickData } from '../data/data-provider.js';
export interface VolumeCanvas {
    texture: GPUTexture;
    size: number;
    bitDepth: BitDepth;
    format: GPUTextureFormat;
}
/**
 * Detect best supported texture format for 16-bit data.
 * uint16 uses r16unorm only if the device validates it as a filterable 3D texture.
 * texture-formats-tier1 alone permits unfilterable r16unorm textures.
 * Otherwise, and for raw-value data (int16/float), r16float; r8unorm as a last resort.
 */
export declare function detectBest16BitFormat(device: GPUDevice, isFloat?: boolean): Promise<GPUTextureFormat>;
/** Create empty volume canvas (atlas texture). Size defaults to the full ATLAS_SIZE. */
export declare function createVolumeCanvas(device: GPUDevice, bitDepth: BitDepth, format: GPUTextureFormat, atlasSize?: number): VolumeCanvas;
/**
 * Write volume data into canvas at specified offset
 * Handles both 8-bit and 16-bit data based on canvas bitDepth
 */
export declare function writeToCanvas(device: GPUDevice, canvas: VolumeCanvas, data: BrickData, size: [number, number, number], offset?: [number, number, number]): void;
/**
 * Generate test volume data with centered sphere
 */
export declare function generateSphereVolume(size: number, radius: number, intensity: number): Uint8Array;
/**
 * Generate solid volume with uniform intensity
 */
export declare function generateSolidVolume(size: [number, number, number], intensity: number): Uint8Array;
