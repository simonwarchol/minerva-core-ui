/**
 * Transfer function - maps density to RGBA color
 */
export type TFPreset = 'grayscale' | 'grayscale-inverted' | 'hot' | 'cool' | 'viridis' | 'plasma' | 'coolwarm' | 'seismic';
export interface OpacityPoint {
    x: number;
    y: number;
}
export declare class TransferFunction {
    private device;
    private size;
    texture: GPUTexture;
    private colorData;
    private opacityPoints;
    preset: TFPreset;
    /** Bumped whenever the texture is rewritten, so other views can tell the look changed. */
    version: number;
    private histogram;
    constructor(device: GPUDevice);
    /** Destroy the GPU texture (the device is external). */
    dispose(): void;
    setPreset(preset: TFPreset): void;
    private getPresetColor;
    private interpolateColormap;
    setOpacityPoints(points: OpacityPoint[]): void;
    getOpacityPoints(): OpacityPoint[];
    /** RGB (0–255) of the colour map at t in [0, 1]. */
    getColor(t: number): [number, number, number];
    private sampleOpacity;
    private updateTexture;
    setHistogram(histogram: Uint32Array): void;
    renderPreview(canvas: HTMLCanvasElement, windowCenter?: number, windowWidth?: number): void;
    private renderHistogram;
}
