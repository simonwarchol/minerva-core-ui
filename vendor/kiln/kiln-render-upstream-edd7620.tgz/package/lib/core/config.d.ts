/** Kiln Configuration — volume rendering and virtual texturing constants. */
import type { PyramidLevel, Vec3 } from './pyramid.js';
export declare const LOGICAL_BRICK_SIZE = 64;
export declare const PHYSICAL_BRICK_SIZE = 66;
export declare const ATLAS_SIZE = 660;
export declare const MAX_BRICK_TRAVERSALS = 512;
export declare const GRID_SIZE: number;
export declare const TOTAL_BRICK_SLOTS: number;
export declare const BRICK_SIZE = 64;
export declare const DEFAULT_ATLAS_BUDGET_BYTES = 1400000000;
export declare const MIN_GRID_SIZE = 6;
/**
 * Largest atlas grid (slots/axis) whose VRAM (numChannels × atlasSize³ ×
 * bytesPerVoxel) fits budgetBytes, clamped to [MIN_GRID_SIZE, GRID_SIZE].
 */
export declare function computeAtlasGrid(numChannels: number, bytesPerVoxel: number, budgetBytes?: number): {
    gridSize: number;
    atlasSize: number;
};
export declare const CONFIG: {
    readonly LOGICAL_BRICK_SIZE: 64;
    readonly PHYSICAL_BRICK_SIZE: 66;
    readonly BRICK_SIZE: 64;
    readonly ATLAS_SIZE: 660;
    readonly GRID_SIZE: number;
    readonly TOTAL_BRICK_SLOTS: number;
    readonly MAX_BRICK_TRAVERSALS: 512;
};
/** Raw-stat threshold below which a brick is empty: ~0.15% of the dtype range (1 for 8-bit),
 *  lowered to the smallest display-window start so windowed signal is never culled. */
export declare function emptyBrickThresholdFor(bitDepth: 8 | 16, windows?: Array<{
    start: number;
} | undefined>, isFloat?: boolean): number;
/**
 * Display window in shader space (0–1 of the stored texture value). Float voxels are
 * normalised by the global dataRange, integer voxels by the dtype range in `w.min/max`.
 */
export declare function normalizeWindow(w: {
    start: number;
    end: number;
    min: number;
    max: number;
}, isFloat: boolean, dataRange?: [number, number]): {
    min: number;
    max: number;
} | null;
/**
 * Immutable value object describing dataset geometry.
 * Computed from VolumeMetadata and injected into subsystems at construction.
 */
export declare class DatasetConfig {
    readonly dimensions: [number, number, number];
    readonly voxelSpacing: [number, number, number];
    /** Bricks per axis at LOD 0 */
    readonly datasetGrid: [number, number, number];
    /** Normalized extent [0–1] per axis, accounting for anisotropic voxel spacing */
    readonly normalizedSize: [number, number, number];
    /** Bricks with max intensity below this value are considered empty; follows the channel windows. */
    emptyBrickThreshold: number;
    /** Level model; absent = legacy uniform 2:1 (exponent [lod, lod, lod]). */
    private readonly levels;
    constructor(dimensions: [number, number, number], voxelSpacing?: [number, number, number], emptyBrickThreshold?: number, levels?: PyramidLevel[]);
    /** Per-axis log2 downsampling of `lod` relative to level 0. */
    levelExponent(lod: number): Vec3;
    /** Finest-grid cells (LOD-0 bricks) one brick of `lod` covers, per axis. */
    levelSpanCells(lod: number): Vec3;
    /** Children per axis when refining from `lod` to `lod - 1`: 1 or 2. */
    childCounts(lod: number): Vec3;
    /** Bricks of `fineLod` per brick of `coarseLod`, per axis. */
    levelRatio(coarseLod: number, fineLod: number): Vec3;
    /** Shader table: finest voxels per level voxel, one vec4 per LOD (w unused), `maxLevels` entries. */
    lodScaleTable(maxLevels: number): Float32Array;
}
