/**
 * GPU side of labels, shared by every view and kept across atlas rebuilds:
 *
 * - pool: one r16uint 3D texture of 66³ slots for all layers. A mixed label brick takes one
 *   slot for its palette indices; background-only and single-ID bricks take none. The texture
 *   starts empty and grows in z (copying what it holds) up to the label budget.
 * - palette: packed RGBA per palette index of every brick in the pool (index 0 transparent).
 * - entries: per shown layer and image atlas slot, how the brick in that slot is labelled.
 * - params: LABEL_UNIFORMS (layer count and per-layer styles).
 * - pick: the label hit under one pixel, written by the shaders for hover and selection.
 *
 * Writes go to CPU mirrors and reach the GPU in flush(), once per frame. `version` changes
 * whenever a texture or buffer is replaced, so renderers know to rebuild their bind groups.
 */
import { SlotAllocator } from './allocators.js';
export declare const LABEL_SLOT_BYTES: number;
/** Default upper bound of the label pool's GPU memory. */
export declare const DEFAULT_LABEL_BUDGET_BYTES: number;
/** Bytes of the pick record: hit position (vec4f), then per layer slot + 1, palette index, colour, kind. */
export declare const PICK_BYTES: number;
/** Entry kinds (low two bits of entry.x); the shader skips anything else. */
export declare const ENTRY_UNIFORM = 2;
export declare const ENTRY_MIXED = 3;
export interface LabelLayerGpuStyle {
    opacity: number;
    /** 0 off, 1 surface, 2 tint */
    mode3d: number;
    /** 0 off, 1 fill, 2 outline, 3 both */
    slice: number;
}
export declare class LabelGpu {
    private readonly device;
    /** Bumped whenever pool, entries or palette is replaced (bind groups must be rebuilt). */
    version: number;
    readonly slots: SlotAllocator;
    /** Slots per axis in x and y; the pool grows in z */
    readonly poolGrid: number;
    /** Most slot layers in z the budget and device allow */
    readonly maxDepth: number;
    pool: GPUTexture;
    entries: GPUBuffer;
    palette: GPUBuffer;
    readonly params: GPUBuffer;
    readonly pick: GPUBuffer;
    private depth;
    private atlasSlots;
    private entryData;
    private entryDirty;
    private readonly ranges;
    private paletteData;
    private paletteDirty;
    private readonly paramsData;
    private paramsDirty;
    private disposed;
    constructor(device: GPUDevice, budgetBytes: number);
    /** Pool bytes allocated on the GPU now, and at most. */
    get poolBytes(): number;
    get maxPoolBytes(): number;
    get paletteBytes(): number;
    /** Grow the pool by doubling its z layers (copying its slots); false at the budget. */
    growPool(): boolean;
    /** Free the pool texture (no layer is shown); every slot must have been released. */
    releasePool(): void;
    /** Upload a brick's palette indices into a pool slot. */
    writeBrick(slot: number, indices: Uint16Array): void;
    /** Entries for an image atlas of `slots` slots, `grid` per axis; all start unlabelled. */
    setAtlas(slots: number, grid: number): void;
    writeEntry(layer: number, slot: number, x: number, y: number, z: number, w: number): void;
    /** Clear the entries of layer rows [from, MAX_LABEL_LAYERS). */
    clearRows(from: number): void;
    /** A palette range for `entries` colours, growing the buffer as needed. */
    allocPalette(entries: number): number;
    freePalette(offset: number, entries: number): void;
    writeColors(offset: number, colors: Uint32Array): void;
    /** Styles of the shown layers, in entry row order. */
    setLayers(layers: readonly LabelLayerGpuStyle[]): void;
    get layerCount(): number;
    /** Send pending writes to the GPU. */
    flush(): void;
    dispose(): void;
    private createPool;
    private createBuffer;
}
