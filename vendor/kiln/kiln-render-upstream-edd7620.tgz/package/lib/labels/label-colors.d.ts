/**
 * Segment colours, resolved on the CPU into the per-brick palettes the shaders read, so a
 * shader never hashes IDs or looks up styles: hiding, isolating or selecting a segment only
 * rewrites palette entries.
 */
export type Rgb = [number, number, number];
/** 0–255 RGBA packed as WGSL's unpack4x8unorm reads it (r in the low byte). */
export declare function packRgba(r: number, g: number, b: number, a: number): number;
export declare function unpackRgba(packed: number): [number, number, number, number];
/**
 * A colour for an ID without one: hues step by the golden ratio, so consecutive IDs (usually
 * neighbours in instance segmentations) differ clearly; saturation and value vary a little more.
 * `seed` shifts the hues per layer, so ID 1 of two binary masks differs.
 */
export declare function segmentColor(id: number, seed?: number): Rgb;
/** Distinct colours for layers shown in one colour, in the order layers are added. */
export declare const LAYER_COLORS: Rgb[];
/** What decides a segment's colour; a layer's style. */
export interface SegmentStyle {
    /** One colour for every segment; null: per-segment colours */
    color: Rgb | null;
    /** Per-layer hue shift for generated colours */
    seed: number;
    /** Colours from metadata (`image-label.colors`), RGBA 0–255 */
    metadata: ReadonlyMap<number, readonly [number, number, number, number]>;
    hidden: ReadonlySet<number>;
    selected: ReadonlySet<number>;
    /** Show only selected segments */
    isolate: boolean;
}
/** Packed RGBA of segment `id` (0: not drawn). */
export declare function resolveColor(id: number, style: SegmentStyle): number;
