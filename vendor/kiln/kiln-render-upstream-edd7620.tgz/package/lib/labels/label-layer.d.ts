/**
 * One label image shown over the volume: its style, segment state (hidden, selected) and,
 * internally, which label brick labels each image atlas slot. Setters only
 * record the change; the LabelManager applies it on the next frame.
 */
import type { LabelImageInfo } from '../data/label-image.js';
import type { Rgb } from './label-colors.js';
/** How a layer shows in 3D: shaded surfaces, a tint of the image, or not at all. */
export type Label3dStyle = 'surface' | 'tint' | 'off';
/** How a layer shows on slices: filled, outlined, both, or not at all. */
export type LabelSliceStyle = 'fill' | 'outline' | 'both' | 'off';
export interface LabelLayerOptions {
    /** Shown (default true; at most MAX_LABEL_LAYERS layers are shown at once) */
    visible?: boolean;
    /** 0–1 (default 0.8): surfaces and outlines at this opacity, slice fills at half of it */
    opacity?: number;
    /** Default 'surface' */
    style3d?: Label3dStyle;
    /** Default 'fill' */
    slice?: LabelSliceStyle;
    /** One colour (0–255 RGB) for every segment (default: a colour per layer); null: per-segment colours */
    color?: Rgb | null;
    /** Segments not drawn */
    hidden?: readonly number[];
    /** Highlighted segments; with `isolate`, the only ones drawn */
    selected?: readonly number[];
    isolate?: boolean;
}
/** Serialisable state of a layer, e.g. for share URLs. */
export interface LabelLayerState extends Required<Omit<LabelLayerOptions, 'hidden' | 'selected'>> {
    source: string;
    hidden: number[];
    selected: number[];
}
/** A segment the metadata knows about. */
export interface LabelSegment {
    id: number;
    /** Name from `image-label.properties` (name, class, label or type), if any */
    name?: string;
    properties?: Record<string, unknown>;
}
/** What labels an image atlas slot: a uniform ID, a brick in the pool, or nothing. */
export type LabelBound = null | {
    kind: 'uniform';
    id: number;
} | {
    kind: 'mixed';
    brick: ResidentLabelBrick;
};
export declare class LabelLayer {
    private readonly host;
    /** As passed to add(): a name from the dataset's labels group or a URL */
    readonly source: string;
    readonly name: string;
    readonly info: LabelImageInfo;
    /** Things to know about this layer (e.g. levels without labels) */
    readonly notes: readonly string[];
    private _visible;
    private _opacity;
    private _style3d;
    private _slice;
    private _color;
    private _isolate;
    private readonly hidden;
    private readonly selected;
    private readonly metadataColors;
    private readonly seed;
    private style;
    get visible(): boolean;
    set visible(value: boolean);
    get opacity(): number;
    set opacity(value: number);
    get style3d(): Label3dStyle;
    set style3d(value: Label3dStyle);
    get slice(): LabelSliceStyle;
    set slice(value: LabelSliceStyle);
    /** One colour for every segment (0–255 RGB), or null for per-segment colours. */
    get color(): Rgb | null;
    set color(value: Rgb | null);
    /** A colour for this layer when it is shown in one colour (distinct per layer). */
    get layerColor(): Rgb;
    segment(id: number): LabelSegment;
    /** Colour segment `id` is drawn with, 0–255 RGBA (alpha 0: not drawn). */
    colorOf(id: number): [number, number, number, number];
    /** Colour of segment `id` ignoring hiding and selection, 0–255 RGB. */
    baseColorOf(id: number): Rgb;
    isHidden(id: number): boolean;
    get hiddenSegments(): ReadonlySet<number>;
    setHidden(ids: number | readonly number[], hidden: boolean): void;
    /** Show every hidden segment again. */
    showAll(): void;
    get selection(): ReadonlySet<number>;
    /** Change the selection: replace it, add to it, or toggle the given segments. */
    select(ids: number | readonly number[], mode?: 'replace' | 'add' | 'toggle'): void;
    clearSelection(): void;
    /** Draw only the selected segments (while there are any). */
    get isolate(): boolean;
    set isolate(value: boolean);
    state(): LabelLayerState;
    private colorsChanged;
}
