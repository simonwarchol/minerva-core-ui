/** Allocators for the label pool: fixed-size brick slots, and variable-size palette ranges. */
/** Free list of slot indices; capacity grows when the pool texture does. */
export declare class SlotAllocator {
    private readonly free;
    private total;
    get capacity(): number;
    get freeCount(): number;
    get usedCount(): number;
    /** Add slots [capacity, capacity + count); lower ones are handed out first. */
    grow(count: number): void;
    /** A free slot, or null when none is. */
    alloc(): number | null;
    release(slot: number): void;
    reset(): void;
}
export declare function paletteClassSize(entries: number): number;
/**
 * Ranges of a growable buffer, in size classes with a free list each, so freed ranges are
 * reused exactly and fragmentation stays bounded without compaction.
 */
export declare class RangeAllocator {
    private cap;
    private readonly freeLists;
    private top;
    private used;
    constructor(cap: number);
    get capacity(): number;
    /** Entries in allocated ranges (size classes, not requested sizes). */
    get usedCount(): number;
    /** Offset of a range for `entries`, or null when the capacity must grow first. */
    alloc(entries: number): number | null;
    release(offset: number, entries: number): void;
    /** Room for at least `entries` more past the top; the caller grows the buffer to the new capacity. */
    growFor(entries: number): number;
    reset(capacity: number): void;
}
