/**
 * LabelManager: label layers over the image, streamed brick for brick alongside it.
 *
 * Every image atlas slot is labelled per shown layer by the label brick at the same address
 * (bindings). Bricks that are background only or one ID need no GPU memory: the entry holds
 * the colour. Mixed bricks go into the shared pool (LabelGpu) and stay there, unused ones
 * evicted first when space runs out. While a brick loads, its slot shows the nearest loaded
 * ancestor, so labels sharpen as the image refines instead of disappearing.
 */
import type { DataProvider, VolumeMetadata } from '../data/data-provider.js';
import type { DatasetConfig } from '../core/config.js';
import type { VolumeResources } from '../core/volume-resources.js';
import type { StreamingManager } from '../streaming/streaming-manager.js';
import type { Vec3 } from '../core/pyramid.js';
import type { LabelGpu } from './label-gpu.js';
import { LabelLayer } from './label-layer.js';
import type { LabelLayerHost, LabelLayerOptions } from './label-layer.js';
/** What the manager needs from the engine. */
export interface LabelHost {
    readonly provider: DataProvider;
    readonly metadata: VolumeMetadata;
    readonly config: DatasetConfig;
    resources(): VolumeResources;
    streaming(): StreamingManager;
    /** A layer was added, removed or restyled: every view re-renders and restarts accumulation */
    redraw(): void;
}
/** A segment under the cursor. */
export interface LabelHit {
    layer: LabelLayer;
    id: number;
    /** Name from the segment's properties, if any */
    name?: string;
    /** Drawn colour, 0–255 RGBA */
    color: [number, number, number, number];
}
/** What a pick found: the finest-level voxel it hit (if any) and the segments there, top layer first. */
export interface LabelPick {
    voxel: Vec3 | null;
    hits: LabelHit[];
}
export interface LabelStats {
    layers: number;
    shown: number;
    /** Label pool GPU memory now and at most */
    poolBytes: number;
    maxPoolBytes: number;
    paletteBytes: number;
    /** Mixed bricks in the pool: labelling a slot, and kept for later */
    bricksInUse: number;
    bricksCached: number;
    /** Label bricks loading or waiting to */
    loading: number;
    bytesFetched: number;
}
export declare class LabelManager implements LabelLayerHost {
    private readonly host;
    readonly gpu: LabelGpu;
    /** Label images in the dataset's `labels` group */
    available: readonly string[];
    /** Layers were added, removed, reordered, shown or hidden: for UIs */
    onChange?: () => void;
    private readonly _layers;
    private readonly resident;
    /** Resident bricks labelling nothing, oldest first: evicted first */
    private readonly unused;
    private readonly loads;
    private queue;
    private inFlight;
    private readonly recent;
    private workers;
    private resources;
    private nextUid;
    private stylesDirty;
    private readonly recolor;
    private disposed;
    constructor(gpu: LabelGpu, host: LabelHost);
    /** Layers in drawing priority: the first is on top where layers overlap. */
    get layers(): readonly LabelLayer[];
    /** Layers shown, in entry row order. */
    get shown(): LabelLayer[];
    /**
     * Open label image `source` (a name from `available` or an OME-Zarr URL) as a new layer, or
     * return the layer already showing it. Rejects when it can't be opened or doesn't fit the image.
     */
    add(source: string, options?: LabelLayerOptions): Promise<LabelLayer>;
    /** Remove a layer and free everything it holds. */
    remove(layer: LabelLayer): void;
    /**
     * Add several layers in order (e.g. from a share URL); each is a source or a source with
     * options. Layers that fail are skipped with a warning.
     */
    addAll(layers: ReadonlyArray<string | (LabelLayerOptions & {
        source: string;
    })>): Promise<LabelLayer[]>;
    /** Move a layer to `index` in the drawing priority. */
    move(layer: LabelLayer, index: number): void;
    /** Follow a new image atlas (engine creation, channel count change): bind its slots afresh. */
    attach(resources: VolumeResources): void;
    /** Per frame: apply style and colour changes, start loads, send writes to the GPU. */
    update(): void;
    /**
     * Resolve a pick record the shaders wrote (see LabelGpu.pick): the hit voxel and, per shown
     * layer, the slot and palette index there. Segments are looked up in the CPU-side palettes.
     */
    resolvePick(record: ArrayBuffer): LabelPick;
    get stats(): LabelStats;
    dispose(): void;
    /** Shown layers get rows in list order; newly shown ones bind every slot, hidden ones unbind. */
    private layout;
    /** Rewrite every entry row and the layer styles. */
    private layoutRows;
    /** The shown layers' opacity and modes (one small uniform write). */
    private applyStyles;
    private slotChanged;
    /** Bind every occupied image slot, coarsest bricks first so the overview labels first. */
    private bindAll;
    private bindSlot;
    /** Bind the slot's own brick if it is known, else the nearest known ancestor and load it. */
    private resolve;
    /** What labels the brick `key` of level `lod`, or undefined while it isn't loaded. */
    private lookup;
    /** The nearest coarser brick that is known, as a stand-in while the slot's own one loads. */
    private ancestor;
    private setBound;
    private unbind;
    private retain;
    private release;
    /** Resolve a waiting slot again (its brick arrived); true when its labels changed. */
    private rebind;
    private writeEntry;
    private key;
    private recentlyFailed;
    private request;
    private pump;
    private start;
    private dropLoad;
    private loaded;
    private failed;
    private setSummary;
    private remember;
    /** Put a mixed brick into the pool (evicting unused bricks or growing it); null when full. */
    private upload;
    private evict;
    private writeColors;
    /** Colours changed: rewrite the layer's palettes and its single-ID entries. */
    private applyColors;
    private imageGeometry;
}
