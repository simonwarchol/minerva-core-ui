/**
 * KilnViewer — self-contained WebGPU volume viewer. Owns the canvas, device,
 * arcball camera, render loop and resize; delegates rendering and streaming to
 * KilnEngine. App layer handles UI.
 */
import { KilnEngine, EngineOptions } from './engine.js';
import type { Renderer, VolumeRenderMode } from './core/renderer.js';
import { Camera, Projection, UpAxis } from './core/camera.js';
import type { TransferFunction, TFPreset } from './core/transfer-function.js';
import type { StreamingManager } from './streaming/streaming-manager.js';
import type { DataProvider, SourceSelection, VolumeMetadata } from './data/data-provider.js';
import type { LoadMilestones } from './core/milestones.js';
import type { LabelManager, LabelPick } from './labels/label-manager.js';
import type { LabelLayerState } from './labels/label-layer.js';
export interface ViewerOptions extends EngineOptions {
    /** Camera up axis */
    upAxis?: UpAxis;
    /** Camera orbit state [rx, ry, dist] or [rx, ry, dist, tx, ty, tz] */
    cam?: [number, number, number] | [number, number, number, number, number, number];
    /** Camera projection; default perspective */
    projection?: Projection;
}
/** Serialisable snapshot of viewer state — used by the share-URL feature */
export interface ViewerState {
    sourceChannels?: number[];
    timepoint?: number;
    mode: VolumeRenderMode;
    windowCenter: number;
    windowWidth: number;
    densityScale: number;
    shading: number;
    gradientOpacity: number;
    isoValue: number;
    /** User-intended render scale (not the 0.25 interaction override) */
    renderScale: number;
    tfPreset: TFPreset;
    tfPoints: Array<{
        x: number;
        y: number;
    }>;
    upAxis: UpAxis;
    cam: [number, number, number, number, number, number];
    projection: Projection;
    clipMin: [number, number, number];
    clipMax: [number, number, number];
    sliceX: number;
    sliceY: number;
    sliceZ: number;
    showSliceX: boolean;
    showSliceY: boolean;
    showSliceZ: boolean;
    showWireframe: boolean;
    showAxis: boolean;
    /** Label layers in drawing priority (see KilnEngine.labels) */
    labels: LabelLayerState[];
}
/** Another view of the viewer's dataset in its own canvas, e.g. one pane of a multi-view layout. */
export interface ViewerPane {
    readonly canvas: HTMLCanvasElement;
    readonly camera: Camera;
    /** This pane's render mode; every other display setting follows the main view. Throws after removal or viewer disposal. */
    mode: VolumeRenderMode;
}
export declare class KilnViewer {
    readonly engine: KilnEngine;
    readonly camera: Camera;
    /** Optional callback invoked at the start of every render frame. */
    onBeforeFrame?: () => void;
    /** Callback invoked when float/channel ranges are derived during base LOD loading. */
    onChannelWindowsChanged?: () => void;
    private readonly context;
    private readonly canvas;
    private readonly format;
    private readonly panes;
    private readonly resizeObserver;
    private rafHandle;
    private resizeTimer;
    private disposed;
    private constructor();
    /** Create a fully initialised KilnViewer from a URL or DataProvider. */
    static create(canvas: HTMLCanvasElement, dataset: string | DataProvider, options?: ViewerOptions): Promise<KilnViewer>;
    get renderer(): Renderer;
    get transferFunction(): TransferFunction;
    get streamingManager(): StreamingManager;
    get device(): GPUDevice;
    get metadata(): VolumeMetadata;
    get milestones(): LoadMilestones;
    /** Label layers (segmentations) over the volume */
    get labels(): LabelManager;
    get mode(): VolumeRenderMode;
    set mode(value: VolumeRenderMode);
    get isoValue(): number;
    set isoValue(value: number);
    get windowCenter(): number;
    set windowCenter(value: number);
    get windowWidth(): number;
    set windowWidth(value: number);
    /** Minimum raw float value that maps to 0.0 in the shader (float32 datasets only). */
    get floatMin(): number;
    set floatMin(value: number);
    /** Maximum raw float value that maps to 1.0 in the shader (float32 datasets only). */
    get floatMax(): number;
    set floatMax(value: number);
    get renderScale(): number;
    set renderScale(value: number);
    /** Projection of the main view and every pane; panes added later start with it. */
    get projection(): Projection;
    set projection(value: Projection);
    /**
     * Show another view of the dataset in `canvas`, e.g. one pane of a multi-view layout. It
     * has its own camera and render mode (starting from the main view's); every other display
     * setting follows the main view. All panes share one render loop and one stream.
     */
    addPane(canvas: HTMLCanvasElement): ViewerPane;
    /** Stop rendering a pane added with addPane(); its canvas stays in the page. */
    removePane(pane: ViewerPane): void;
    /** Whether `canvas` shows this viewer: the main canvas or a pane's. */
    ownsCanvas(canvas: EventTarget | null): canvas is HTMLCanvasElement;
    /**
     * Label segments under a point of the main canvas or a pane's canvas, in client (CSS) pixels,
     * e.g. a pointer event's clientX/clientY (see KilnEngine.pickLabels). Null when the canvas
     * isn't this viewer's or no label layer is shown.
     */
    pickLabels(canvas: HTMLCanvasElement, clientX: number, clientY: number): Promise<LabelPick | null>;
    /** Switch source channels/timepoint in place (see KilnEngine.setSourceSelection); the camera stays. */
    setSourceSelection(selection: SourceSelection): void;
    getState(): ViewerState;
    /** Render the current view and encode it as an image; call once the view has converged. */
    captureImage(type?: string): Promise<Blob>;
    dispose(): void;
    /** Match every canvas's drawing buffer to its CSS size now; window resizes are followed after 100 ms. */
    resize(): void;
    private resizeCanvas;
    private frame;
}
