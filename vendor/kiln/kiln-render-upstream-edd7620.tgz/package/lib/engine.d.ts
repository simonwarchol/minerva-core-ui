/**
 * KilnEngine — headless volume engine. Owns the renderer, streaming and GPU
 * resources on a caller-supplied device, and renders into any colour view for
 * any camera. No canvas, no input handling, no frame loop: KilnViewer adds
 * those for standalone use; other hosts drive it from their own scene and camera.
 */
import type { LoadMilestones } from './core/milestones.js';
import type { PyramidPolicy } from './core/pyramid.js';
import { Renderer, VolumeRenderMode } from './core/renderer.js';
import { VolumeResources } from './core/volume-resources.js';
import { TransferFunction, TFPreset } from './core/transfer-function.js';
import { StreamingManager } from './streaming/streaming-manager.js';
import { DatasetConfig } from './core/config.js';
import type { ViewParams } from './core/view.js';
import type { DataProvider, SourceSelection, VolumeMetadata } from './data/data-provider.js';
import { LabelManager } from './labels/label-manager.js';
import type { LabelPick } from './labels/label-manager.js';
import type { LabelLayerOptions } from './labels/label-layer.js';
export interface EngineOptions {
    /** Zero-based OME-Zarr source channels, in display order (one to four). */
    sourceChannels?: readonly number[];
    /** Zero-based OME-Zarr timepoint. Both can be switched later with setSourceSelection(). */
    timepoint?: number;
    /** Initial render mode */
    mode?: VolumeRenderMode;
    /** 16-bit window centre (0–1) */
    windowCenter?: number;
    /** 16-bit window width (0–1) */
    windowWidth?: number;
    /** DVR density / opacity scale (0.1–10, default 1) */
    densityScale?: number;
    /** DVR gradient shading strength (0–1, default 0; 0 = flat) */
    shading?: number;
    /** DVR boundary emphasis: opacity follows gradient magnitude (0–1, default 0 = off) */
    gradientOpacity?: number;
    /** Isosurface threshold (0–1) */
    isoValue?: number;
    /** Render resolution scale (0.25–1) */
    renderScale?: number;
    /** LOD screen-space error threshold in pixels */
    maxPixelError?: number;
    /**
     * Atlas VRAM budget in bytes (default ~1.3 GiB). The grid shrinks to fit;
     * lower it for constrained mobile GPUs, raise it to keep 660³ for many channels.
     */
    atlasBudgetBytes?: number;
    /** Axis-aligned clip minimum, normalised 0–1 */
    clipMin?: [number, number, number];
    /** Axis-aligned clip maximum, normalised 0–1 */
    clipMax?: [number, number, number];
    /** Transfer function colour preset */
    tfPreset?: TFPreset;
    /** Transfer function opacity control points (overrides preset defaults) */
    tfPoints?: Array<{
        x: number;
        y: number;
    }>;
    /** performance.now() when the host obtained the GPU device (for load milestones) */
    deviceReadyAt?: number;
    /** Slice plane positions, normalised 0–1 */
    sliceX?: number;
    sliceY?: number;
    sliceZ?: number;
    /** Slice plane visibility flags (default true) */
    showSliceX?: boolean;
    showSliceY?: boolean;
    showSliceZ?: boolean;
    /** Overlay toggles */
    showWireframe?: boolean;
    showAxis?: boolean;
    /** Format of the colour view passed to render() (default: preferred canvas format) */
    outputFormat?: GPUTextureFormat;
    /**
     * Level model: 'native' per-axis factors from metadata, or 'legacy' uniform 2:1 virtual pyramid.
     * Unset: native, falling back to legacy when the stored levels don't fit the native model
     * (e.g. a coarse level a few voxels short of half its parent). Setting it disables the fallback.
     */
    pyramid?: PyramidPolicy;
    /** Initial per-channel visibility (multichannel): hidden channels start with alpha 0 and are
     *  not streamed until shown. Overrides OMERO `active`. */
    visibleChannels?: boolean[];
    /**
     * Label layers to show, in drawing priority: names from the dataset's OME-Zarr `labels` group
     * or URLs of OME-Zarr label images, optionally with a style. They open after the engine is
     * created (see `engine.labels`); ones that can't be shown are skipped with a warning.
     */
    labels?: ReadonlyArray<string | (LabelLayerOptions & {
        source: string;
    })>;
    /** Upper bound of the label pool's GPU memory in bytes (default 512 MiB; it grows only as needed). */
    labelBudgetBytes?: number;
}
export declare class KilnEngine {
    readonly device: GPUDevice;
    readonly transferFunction: TransferFunction;
    readonly dataProvider: DataProvider;
    /** Shared with the provider and streaming manager; setSourceSelection() updates it in place. */
    readonly metadata: VolumeMetadata;
    readonly config: DatasetConfig;
    private readonly views;
    private _resources;
    private _streamingManager;
    /** View 0's renderer; its display settings (all but the render mode) are shared by every view. */
    get renderer(): Renderer;
    get resources(): VolumeResources;
    get streamingManager(): StreamingManager;
    /** Label layers (segmentations) over the volume: add, style, pick. */
    readonly labels: LabelManager;
    /** Callback invoked when float/channel ranges are derived during base LOD loading. */
    onChannelWindowsChanged?: () => void;
    /** Render scale used while the camera is moving. 0 disables the drop. */
    interactionRenderScale: number;
    /** User-intended render scale; update() may temporarily override it during interaction. */
    private userRenderScale;
    private disposed;
    private readonly vpScratch;
    private readonly gpu;
    private readonly setupMilestones;
    private firstContentSubmit;
    private firstContentFrame;
    private constructor();
    /**
     * Request a device with the limits Kiln needs (large buffers, large 3D textures), and
     * texture-formats-tier1 where available. Atlas setup separately validates filtering
     * before selecting lossless r16unorm storage.
     */
    static createDevice(): Promise<GPUDevice>;
    /** Create a fully initialised engine on `device` from a URL or DataProvider. */
    static create(device: GPUDevice, dataset: string | DataProvider, options?: EngineOptions): Promise<KilnEngine>;
    /** Every base brick is pinned, so the coarsest level must fit the atlas for `numChannels`,
     *  plus one working slot when finer levels exist; otherwise loading leaves permanent holes. */
    private static assertBaseFits;
    /** Atlas sized to the budget for this channel count, plus the renderer that samples it. */
    private static buildGpu;
    /** A renderer that samples `resources`. */
    private static buildRenderer;
    /** Renderer for a view other than 0: same atlas and transfer function, view 0's look. */
    private buildViewRenderer;
    /** Redraw requests and ray visibility of a view's renderer. */
    private wireView;
    /** Start streaming into `resources` for every view; derived ranges flow back into view 0's renderer. */
    private attachStreaming;
    /**
     * Switch source channels and/or timepoint without reopening the dataset: metadata,
     * workers, camera and display settings stay; bricks re-stream (unchanged channels and
     * revisited timepoints come from the CPU brick cache). Slots whose channel changed take
     * that channel's metadata defaults; a time-only change keeps every display setting.
     * A different channel count rebuilds the atlas and renderer on the same device.
     */
    setSourceSelection(selection: SourceSelection): void;
    /** New atlas + renderers for the current channel count; display state carries over, streaming restarts. */
    private rebuildGpu;
    /** User-intended render scale (the interaction override is not reflected here). */
    get renderScale(): number;
    set renderScale(value: number);
    /** Number of views: 1, plus one per addView(). */
    get viewCount(): number;
    /** Renderer of view `view`. Set its `volumeRenderMode` per view; other display settings follow view 0. */
    getRenderer(view?: number): Renderer;
    /**
     * Add a view of the same data, e.g. one pane of a multi-view layout. It streams from the
     * same atlas and has its own camera (the ViewParams passed for it), render mode and
     * accumulation; every other display setting follows view 0. Returns its index for
     * setSize(), updateViews() and render(); call setSize() before rendering it.
     */
    addView(): number;
    /** Remove a view added with addView(); later views move down one index. */
    removeView(view: number): void;
    /** Output size of view `view` in device pixels. Call whenever its colour view changes size. */
    setSize(width: number, height: number, view?: number): void;
    /** Signal that the scene needs a re-render (without resetting accumulation). */
    markDirty(): void;
    /**
     * Advance streaming and render-scale state for this frame's view.
     * Returns true when the caller should call render(): something changed or
     * temporal accumulation has not converged yet.
     */
    update(view: ViewParams): boolean;
    /**
     * update() for several views: `views[i]` is the camera of view i. Streams what any of
     * them needs and returns, per view, whether to call render() for it.
     */
    updateViews(views: readonly ViewParams[]): boolean[];
    /** Camera tracking of one view: whether it is interacting, and the render scale for that. */
    private trackView;
    /** Render view `index` (default 0) for camera `view` into `colorView` (format = options.outputFormat). */
    render(colorView: GPUTextureView, view: ViewParams, index?: number): void;
    /**
     * Label segments under pixel (x, y) of view `view`, in output pixels: the front-most drawn
     * label along the ray in volume modes, the slice plane under the pixel in slice mode. Resolves
     * with the hit voxel and one hit per shown layer with a segment there (top layer first), or null
     * when no layer is shown or a newer pick replaced this one.
     */
    pickLabels(x: number, y: number, view?: number): Promise<LabelPick | null>;
    /** Host hook: call at the start of each animation frame to record the presentation proxy. */
    noteAnimationFrame(now?: number): void;
    /** Load milestones, all as performance.now() timestamps since navigation start. */
    get milestones(): LoadMilestones;
    /** Stop streaming and release engine-owned GPU resources; the device stays with its owner. */
    dispose(): void;
}
