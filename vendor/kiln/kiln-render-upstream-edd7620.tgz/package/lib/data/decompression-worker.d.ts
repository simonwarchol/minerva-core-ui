/** DecompressionWorker - Off-main-thread gzip decompression via fflate. */
import type { SourceFormat, TargetFormat } from './brick-convert.js';
export interface DecompressRequest {
    id: number;
    data: ArrayBuffer;
    /** Source voxel dtype; without it no conversion is applied. */
    sourceFormat?: SourceFormat;
    /** Target texture format: r8unorm (8-bit), r16unorm (16-bit uint), r16float (16-bit float) */
    targetFormat?: TargetFormat;
}
export interface DecompressResponse {
    id: number;
    data: ArrayBuffer | null;
    error?: string;
}
