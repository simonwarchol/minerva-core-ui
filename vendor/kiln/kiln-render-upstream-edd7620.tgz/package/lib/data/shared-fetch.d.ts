/**
 * Generic refcounted in-flight request coalescing with correct abort
 * semantics: the shared operation runs under its own AbortController, not
 * any single caller's signal, so cancelling one caller can't kill it for
 * others still waiting on it — it's only aborted once every caller has
 * released (refs reaches 0). If a caller is still interested when the shared
 * operation *does* get aborted (a race between a release and a new caller
 * arriving), it recurses into a fresh registration instead of running its own
 * standalone duplicate, so any other still-interested caller coalesces onto
 * the new shared operation too.
 *
 * Extracted as a pure, dependency-free utility (no zarr/worker specifics) so
 * the concurrency logic — the riskiest part of this class of fix — can be
 * unit-tested in isolation. Used by zarr-chunk-worker.ts behind ?p4=1 to fix
 * bug B4 (see docs/audits/kiln-render - fetch_patterns.md): the previous
 * dedup tied a shared fetch's lifetime to the FIRST caller's signal, so
 * cancelling that caller killed the fetch for every other caller sharing it,
 * and survivors retried without re-registering (up to N duplicate requests).
 */
export declare class SharedFetchRegistry<T> {
    private entries;
    /**
     * Run `fetch(signal)` for `key`, coalescing concurrent callers for the same
     * key onto one shared invocation. `fetch` is only invoked when no shared
     * invocation is currently registered for `key`.
     */
    run(key: string, fetch: (signal: AbortSignal) => Promise<T>, signal?: AbortSignal): Promise<T>;
    /** Number of keys with a currently in-flight shared fetch — for tests/diagnostics. */
    get size(): number;
}
