/**
 * ZarrDataProvider - Loads OME-Zarr (NGFF) datasets over HTTP via a Web Worker pool.
 * Zarr [z,y,x] metadata is swapped to Kiln's [x,y,z]; memory layout is unchanged.
 */
import { BaseZarrProvider } from './base-zarr-provider.js';
import type { VolumeMetadata, BrickLoadResult, PipelineTimings } from './data-provider.js';
/**
 * DataProvider implementation for OME-Zarr (NGFF v0.5) volumes over HTTP
 */
export declare class ZarrDataProvider extends BaseZarrProvider {
    private url;
    /** URL of the image group (the bioformats2raw "0" sub-group when there is one), set by initialize() */
    private groupUrl;
    /** Worker pool for off-main-thread brick loading */
    private workerPool;
    private targetFormat?;
    constructor(url: string);
    listLabels(): Promise<string[]>;
    labelLocation(source: string): string;
    /**
     * Set target texture format for worker output
     * Format determines output format: r8unorm (8-bit), r16unorm (16-bit uint), r16float (16-bit float)
     */
    setTargetFormat(format: 'r8unorm' | 'r16unorm' | 'r16float'): Promise<void>;
    /** Zarr v2 OME open in two round trips: root + bioformats2raw "0" attrs, then all .zarray in
     *  parallel; arrays come from that JSON and workers get it too. null → not v2, caller probes. */
    private openV2Fast;
    initialize(): Promise<VolumeMetadata>;
    /** Load a fully assembled 66³ brick via the worker pool (fully off main thread). */
    loadBrick(lod: number, bx: number, by: number, bz: number, channelIndex?: number, signal?: AbortSignal): Promise<BrickLoadResult | null>;
    /**
     * Update the float normalisation range on all workers.
     * Called after base LOD loading derives the actual data range.
     */
    setFloatRange(min: number, max: number): Promise<void>;
    getPipelineTimings(): PipelineTimings;
    dispose(): void;
}
/** An absolute URL (any scheme), as opposed to a label name. */
export declare function isUrl(source: string): boolean;
