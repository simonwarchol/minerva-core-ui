/**
 * Local Zarr file picker and loader
 */
export declare function isFileSystemAccessSupported(): boolean;
export declare function promptForZarrDirectory(): Promise<FileSystemDirectoryHandle>;
export declare function getStoredHandle(): Promise<FileSystemDirectoryHandle | null>;
export declare function requestPermission(handle: FileSystemDirectoryHandle): Promise<boolean>;
