/**
 * Reads label bricks of remote label images through one small worker pool per engine
 * (label-worker.ts), however many images are shown. Assembly is label-assembly.ts.
 */
import type { LabelBrickData } from './label-assembly.js';
import type { ImageGeometry, LabelImageInfo, LabelLevelParams } from './label-image.js';
/** Loads label bricks of one label image. */
export interface LabelReader {
    /** Brick (bx, by, bz) of image level `level`; rejects on errors, AbortError when aborted. */
    load(level: LabelLevelParams, bx: number, by: number, bz: number, signal?: AbortSignal): Promise<LabelBrickData>;
    /** Network bytes read so far */
    readonly bytesFetched: number;
    dispose(): void;
}
/** A label image ready to read: its metadata, how each image level reads it, and the reader. */
export interface OpenedLabelImage {
    info: LabelImageInfo;
    levels: Array<LabelLevelParams | null>;
    notes: string[];
    reader: LabelReader;
}
/** Worker pool shared by the label images of one engine. */
export declare class LabelWorkerPool {
    private readonly workers;
    private readonly pending;
    private readonly started;
    private nextId;
    private nextSource;
    private disposed;
    constructor(size?: number);
    /** Register the label image at `url` with every worker; the reader routes its bricks. */
    addSource(url: string, info: LabelImageInfo): Promise<LabelReader>;
    private request;
    dispose(): void;
}
/** Open the label image at `url`, align it to the image (see alignLabelLevels) and get a reader for it. */
export declare function openLabelImage(url: string, name: string, image: ImageGeometry, pool: () => LabelWorkerPool): Promise<OpenedLabelImage>;
