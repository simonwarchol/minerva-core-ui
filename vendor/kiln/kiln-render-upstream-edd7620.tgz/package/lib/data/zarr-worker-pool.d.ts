/** ZarrWorkerPool - Pool of Web Workers for parallel brick loading; main
 *  thread only uploads to GPU. workerIndexFor hashes on spatial+channel
 *  footprint so a brick's channels spread across workers, not one. */
import type { ZarrWorkerRequest } from './zarr-chunk-worker.js';
import type { ArrayMetadata, DataType } from 'zarrita';
import type { PipelineTimings } from './data-provider.js';
export interface BrickResult {
    data: Uint8Array | Uint16Array;
    min: number;
    max: number;
    avg: number;
    /** Raw-space min (float datasets only) */
    rawMin?: number;
    /** Raw-space max (float datasets only) */
    rawMax?: number;
    /** Real network bytes fetched for this brick's chunks (delta since this worker's previous response). */
    chunkBytesFetched?: number;
    /** Real HTTP requests issued for this brick's chunks (delta since this worker's previous response). */
    chunkRequestsIssued?: number;
}
export declare class ZarrWorkerPool {
    private poolSize;
    private workers;
    private nextWorkerIndex;
    private requestId;
    private pendingRequests;
    private is16bit;
    private queueAvg;
    private fetchAvg;
    private assemblyAvg;
    private chunkHitTotal;
    private bytesByChunk;
    private coreChunks;
    private chunkReqTotal;
    /** Per-worker last-seen cumulative store bytes/requests, for delta computation. */
    private workerLastBytes;
    private workerLastRequests;
    /** Stored from init() for spatial worker routing (see workerIndexFor). */
    private lodParams;
    private logicalBrickSize;
    /** Maps request ID → worker index, for routing cancel messages */
    private requestToWorker;
    /** Abort listeners to clean up on normal completion (prevents stale cancel messages) */
    private abortListeners;
    constructor(poolSize?: number);
    /**
     * Initialize all workers with the dataset URL, array paths, and brick params.
     */
    init(url: string, paths: string[], lodParams: ZarrWorkerRequest['lodParams'], logicalBrickSize: number, physicalBrickSize: number, is16bit: boolean, targetFormat?: 'r8unorm' | 'r16unorm' | 'r16float', isFloat32?: boolean, floatRange?: [number, number], arrayMetadata?: ArrayMetadata<DataType>[]): Promise<void>;
    /**
     * Reconfigure target texture format after initialization
     * Format determines output format: r8unorm (8-bit), r16unorm (16-bit uint), r16float (16-bit float)
     */
    setTargetFormat(format: 'r8unorm' | 'r16unorm' | 'r16float'): Promise<void>;
    /** Deterministic worker index for one brick+channel; -1 (round-robin) if
     *  lodParams are missing. Hashes channelIndex too, so a brick's channels
     *  spread across workers instead of piling onto one. */
    private workerIndexFor;
    /** Hash-from-chunk-coords half of workerIndexFor, so routing stays one
     *  shared implementation. `channelIndex` defaults to 0 for callers with no channel axis. */
    private workerIndexForChunk;
    /** Load a 66³ brick, routed to a worker by spatial+channel footprint. Supports AbortSignal cancellation. */
    loadBrick(lod: number, bx: number, by: number, bz: number, channelIndex?: number, signal?: AbortSignal, timepoint?: number): Promise<BrickResult>;
    /**
     * Update the float normalisation range on all workers.
     * Called after base LOD loading derives the actual data range.
     */
    setFloatRange(min: number, max: number): Promise<void>;
    getPipelineTimings(): PipelineTimings;
    terminate(): void;
}
