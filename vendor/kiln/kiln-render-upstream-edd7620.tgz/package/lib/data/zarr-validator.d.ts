/**
 * Zarr dataset validation for Kiln Render. Supports OME-NGFF v0.4/v0.5.
 * Shared by dialog pre-validation and provider-level safety-net.
 */
import type { SpatialOrder } from './chunk-math.js';
interface MultiscalesEntry {
    axes?: unknown;
    datasets: {
        path: string;
    }[];
    version?: string;
}
/** Normalised axis descriptor used internally */
export interface NormalizedAxis {
    name: string;
    type: string;
}
/** Normalise axes from OME-NGFF v0.4 (strings) / v0.5 (typed objects) to uniform shape. */
export declare function normalizeAxes(raw: unknown): NormalizedAxis[];
/**
 * Extract the first multiscales entry from zarr group attrs.
 * Handles both v0.5 layout (attrs.ome.multiscales) and v0.4 (attrs.multiscales).
 */
export declare function extractMultiscales(attrs: Record<string, unknown>): MultiscalesEntry | null;
/** Where x, y and z sit within the last three array dimensions, from the axis names.
 *  Unnamed or unrecognised spatial axes are taken as the usual z, y, x. */
export declare function spatialOrder(axes: NormalizedAxis[], rank: number): SpatialOrder;
/**
 * Validate whether a dataset is supported.
 * Returns a list of human-readable reasons; empty array means fully supported.
 */
export declare function validateZarrSupport(ms: MultiscalesEntry, firstArrayShape: number[], dtype: string): string[];
/** Pre-validate a remote zarr URL (metadata only, no volume data fetched). */
export declare function preValidateRemoteZarr(url: string): Promise<string[]>;
/**
 * Pre-validate a local zarr directory handle.
 * Same logic as preValidateRemoteZarr but reads from the local filesystem.
 */
export declare function preValidateLocalZarr(handle: FileSystemDirectoryHandle): Promise<string[]>;
export {};
