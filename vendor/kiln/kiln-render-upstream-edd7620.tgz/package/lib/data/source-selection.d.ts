import type { SourceSelection } from './data-provider.js';
/** Resolve and validate once, before any data fetches or GPU allocation. */
export declare function resolveSourceSelection(selection: SourceSelection, channels: number, timepoints: number): {
    sourceChannels: number[];
    timepoint: number;
};
