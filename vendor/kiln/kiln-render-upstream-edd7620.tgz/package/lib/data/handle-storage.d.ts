/**
 * IndexedDB storage for FileSystemDirectoryHandle
 */
export declare function storeHandle(handle: FileSystemDirectoryHandle): Promise<void>;
export declare function getHandle(): Promise<FileSystemDirectoryHandle | null>;
export declare function clearHandle(): Promise<void>;
