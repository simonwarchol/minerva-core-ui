/**
 * Level-model fallback for dataset open: prefer the native pyramid (per-axis factors
 * from the metadata) and fall back to the legacy uniform 2:1 model when the stored
 * levels are slightly off — e.g. a coarse level a few voxels short of half its parent.
 */
import type { PyramidPolicy } from '../core/pyramid.js';
import type { DataProvider, VolumeMetadata } from './data-provider.js';
import { UnsupportedDatasetError } from './data-provider.js';
/** True when the only problem was the native level geometry (the provider appends LEGACY_HINT). */
export declare function isNativePyramidRejection(e: unknown): e is UnsupportedDatasetError;
/**
 * Initialise `provider` with the `requested` level model (default native). When nothing was
 * requested and native is rejected only for its level geometry, retry once with legacy.
 * Only Kiln's Zarr providers are retried: their initialize() stores nothing before the
 * pyramid check throws, so a second call starts clean. An explicit request is never overridden.
 */
export declare function initializeWithPyramidFallback(provider: DataProvider, requested?: PyramidPolicy): Promise<{
    metadata: VolumeMetadata;
    pyramid: PyramidPolicy;
}>;
