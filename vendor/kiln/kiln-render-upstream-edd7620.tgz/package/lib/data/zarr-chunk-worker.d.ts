/**
 * ZarrChunkWorker - Web Worker that fetches, decompresses, and assembles
 * 66³ bricks entirely off-thread, transferring results back zero-copy.
 */
import type { DataType, ArrayMetadata } from 'zarrita';
/** Messages from main thread to worker */
export interface ZarrWorkerRequest {
    type: 'init' | 'loadBrick' | 'setTargetFormat' | 'setFloatRange' | 'cancel';
    id: number;
    /** For 'init': dataset URL and array paths */
    url?: string;
    paths?: string[];
    /** For 'loadBrick': brick parameters */
    lod?: number;
    bx?: number;
    by?: number;
    bz?: number;
    /** Brick assembly parameters (sent with init, cached in worker) */
    logicalBrickSize?: number;
    physicalBrickSize?: number;
    /** Per-LOD scale factors and chunk info (sent with init) */
    lodParams?: {
        scaleX: number;
        scaleY: number;
        scaleZ: number;
        actualDimX: number;
        actualDimY: number;
        actualDimZ: number;
        csx: number;
        csy: number;
        csz: number;
        shapePrefixLength: number;
        channelAxisIdx: number;
        channelChunkSize: number;
        timeAxisIdx?: number;
        timeChunkSize?: number;
        timepoint?: number;
        spatialOrder?: [number, number, number];
    }[];
    /** Channel index to load (for datasets with a channel axis) */
    channelIndex?: number;
    /** Time index to load; defaults to the lodParams timepoint fixed at init. */
    timepoint?: number;
    /**
     * Main-thread timestamp (Date.now — NOT performance.now, which has a
     * per-context time origin and can't be diffed across the worker boundary)
     * when request was dispatched, for queue wait measurement.
     */
    dispatchTime?: number;
    is16bit?: boolean;
    /** Target texture format: r8unorm (8-bit), r16unorm (16-bit uint), r16float (16-bit float) */
    targetFormat?: 'r8unorm' | 'r16unorm' | 'r16float';
    /** Whether source data is float32/float64 */
    isFloat32?: boolean;
    /**
     * Feature flag ?p4=1. OFF → the original in-flight dedup (control): a
     * shared fetch runs under the FIRST caller's signal, so cancelling that
     * caller kills the fetch for every other caller sharing it, and survivors
     * retry without re-registering (up to N duplicate requests — bug B4). ON →
     * refcounted dedup (fetchChunkShared): the shared fetch runs under its own
     * AbortController, only aborted once every caller has released. See
     * docs/audits/kiln-render - fetch_patterns.md and src/core/feature-flags.ts.
     */
    refcountedAborts?: boolean;
    /**
     * For 'init' (?bench=1, read on the main thread): attribute downloaded bytes
     * to chunks and report which chunks each brick's core needs, so the bench
     * can show what the one-voxel ghost border costs.
     */
    trackChunkBytes?: boolean;
    /** Float normalisation range — voxel values are mapped from [floatMin, floatMax] → [0, 65535] */
    floatMin?: number;
    floatMax?: number;
    /**
     * For 'init': per-level array metadata already fetched on the main thread,
     * so arrays are built here without any network round trips.
     */
    arrayMetadata?: ArrayMetadata<DataType>[];
}
/** Messages from worker to main thread */
export interface ZarrWorkerResponse {
    type: 'init' | 'loadBrick' | 'setTargetFormat' | 'setFloatRange';
    id: number;
    error?: string;
    /** For 'loadBrick': assembled brick data (transferable) */
    data?: ArrayBuffer;
    /** Brick stats */
    min?: number;
    max?: number;
    avg?: number;
    /** Raw-space min/max for float data (before normalisation) — used for range derivation */
    rawMin?: number;
    rawMax?: number;
    /** Per-stage timing (ms) — for pipeline telemetry */
    fetchMs?: number;
    assemblyMs?: number;
    /** Worker queue wait: dispatchTime → worker starts processing (ms) */
    queueMs?: number;
    /** Chunk-cache hit ratio for this brick (hits / total chunks needed) */
    chunkHits?: number;
    chunkTotal?: number;
    /**
     * Cumulative real network bytes/requests fetched by this worker's store so
     * far (never reset) — the pool diffs consecutive values per worker to get
     * an exact delta without needing a shared/reset-able counter.
     */
    chunkStoreBytes?: number;
    chunkStoreRequests?: number;
    /** ?bench=1 only: cache keys of the chunks this brick's core touches */
    coreChunkKeys?: string[];
    /** ?bench=1 only: bytes downloaded per chunk, for fetches this brick waited on */
    fetchedChunkBytes?: [string, number][];
}
