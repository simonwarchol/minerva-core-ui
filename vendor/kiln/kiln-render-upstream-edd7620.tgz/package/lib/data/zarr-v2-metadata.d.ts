/**
 * Zarr v2 `.zarray` → zarrita v3 ArrayMetadata, so arrays can be constructed
 * from JSON we already fetched (main thread and workers) instead of letting
 * zarrita probe zarr.json/.zattrs/.zarray per array over the network.
 *
 * Mirrors zarrita's internal v2_to_v3_array_metadata (MIT, not exported).
 */
import type { ArrayMetadata, DataType } from 'zarrita';
export interface ZarrV2ArrayJson {
    shape: number[];
    chunks: number[];
    dtype: string;
    compressor: ({
        id: string;
    } & Record<string, unknown>) | null;
    filters?: ({
        id: string;
    } & Record<string, unknown>)[] | null;
    fill_value: unknown;
    order?: 'C' | 'F';
    dimension_separator?: '.' | '/';
}
export declare function v2ToV3ArrayMetadata(meta: ZarrV2ArrayJson, attributes?: Record<string, unknown>): ArrayMetadata<DataType>;
/** Compression label for VolumeMetadata.compression from a v2 compressor entry. */
export declare function compressionLabel(compressor: ZarrV2ArrayJson['compressor']): string | undefined;
