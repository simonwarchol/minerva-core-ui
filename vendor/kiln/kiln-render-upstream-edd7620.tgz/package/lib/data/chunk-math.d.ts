/** Zarr chunk-range math for assembleBrick: which chunks a brick's fetch
 *  touches, and the LUT clamp keeping per-voxel assembly in range. */
export interface LodChunkParams {
    scaleX: number;
    scaleY: number;
    scaleZ: number;
    actualDimX: number;
    actualDimY: number;
    actualDimZ: number;
    csx: number;
    csy: number;
    csz: number;
}
export interface ChunkRange {
    minCx: number;
    maxCx: number;
    minCy: number;
    maxCy: number;
    minCz: number;
    maxCz: number;
}
export interface BrickChunkFootprint extends ChunkRange {
    /** Virtual-space voxel origin (pre-chunk-mapping) — assembleBrick reuses
     *  these for its per-axis LUTs, so they're returned rather than recomputed. */
    vStartX: number;
    vStartY: number;
    vStartZ: number;
}
/** Which Zarr chunks a virtual brick's fetch touches, in this LOD's actual
 *  (downsampled) array space. `logicalSize`/`physSize` are LOGICAL_BRICK_SIZE/
 *  PHYSICAL_BRICK_SIZE (66³ physical brick, 1-voxel ghost border on each side). */
export declare function computeBrickChunkFootprint(params: LodChunkParams, bx: number, by: number, bz: number, logicalSize: number, physSize: number): BrickChunkFootprint;
/** Which Zarr chunks a brick's logical core (without the ghost border) touches,
 *  in the same space as computeBrickChunkFootprint. Chunks in the footprint but
 *  not here are fetched only for the one-voxel border. */
export declare function computeBrickCoreChunkRange(params: LodChunkParams, bx: number, by: number, bz: number, logicalSize: number): ChunkRange;
/** Bench accounting: total downloaded chunk payload bytes (excluding shared shard indexes), and the part from chunks
 *  that no brick's core needed (downloaded only for ghost borders). */
export declare function summarizeBorderBytes(bytesByChunk: ReadonlyMap<string, number>, coreChunks: ReadonlySet<string>): {
    chunkBytes: number;
    borderOnlyBytes: number;
};
/** Worst-case chunks one brick footprint can touch at this LOD, per channel —
 *  shared by the fanout diagnostic and the (graduated) dynamic cache budget. */
export declare function estimateBrickChunkFanout(params: LodChunkParams, physSize: number): number;
/** Largest per-brick chunk fanout across all LODs, for sizing the (shared)
 *  per-worker chunk cache. Falls back to 8 if no LOD params are available. */
export declare function estimateDatasetFanoutMultiplier(lodParamsList: LodChunkParams[], physSize: number): number;
/** Positions of x, y and z within the last three array dimensions. */
export type SpatialOrder = [number, number, number];
/** The usual OME-Zarr layout, `…, z, y, x`. webKnossos writes `…, x, y, z`, which is [0, 1, 2]. */
export declare const ZYX: SpatialOrder;
/** The x, y and z entries of a per-dimension vector (shape, chunks, scale). */
export declare function pickXyz(v: readonly number[], order?: SpatialOrder): [number, number, number];
/** Zarr chunk coordinates for channel and time; other prefix axes are pinned to 0. */
export declare function chunkCoords(prefixLength: number, channelAxisIdx: number, channelChunkSize: number, channel: number, cz: number, cy: number, cx: number, order?: SpatialOrder, timeAxisIdx?: number, timeChunkSize?: number, timepoint?: number): number[];
/** Flat-index layout of a decoded chunk, valid for C, F and transposed storage orders. */
export interface ChunkLayout {
    /** Offset of `channel` inside a chunk that packs several channels (0 otherwise). */
    base: number;
    strideX: number;
    strideY: number;
    strideZ: number;
}
export declare function chunkLayout(chunk: {
    shape: number[];
    stride?: number[];
}, channelAxisIdx: number, channelChunkSize: number, channel: number, order?: SpatialOrder, timeAxisIdx?: number, timeChunkSize?: number, timepoint?: number): ChunkLayout;
/** One axis of the assembly LUT: the footprint bounds maxC via FLOOR but
 *  per-voxel assembly ROUNDs, so the index can land outside [minC, maxC] on
 *  non-integer scales — clamp it into range. */
export declare function clampedLutEntry(virtualCoord: number, scale: number, actualDim: number, cs: number, minC: number, maxC: number): {
    chunkIdx: number;
    offset: number;
};
