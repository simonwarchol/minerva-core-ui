/**
 * Label brick assembly: read a 66³ brick of label IDs on the image's level grid (see
 * alignLabelLevels) and compress it into a palette of distinct IDs plus 16-bit per-voxel
 * palette indices. Most bricks are background only or one ID, and need no voxels at all.
 */
import type { LabelLevelParams } from './label-image.js';
export declare const LABEL_LOGICAL_SIZE = 64;
export declare const LABEL_PHYSICAL_SIZE = 66;
/** Most distinct IDs in one brick (16-bit palette indices). */
export declare const MAX_BRICK_IDS = 65535;
/** A label brick: background only, one ID throughout, or a palette with per-voxel indices. */
export interface LabelBrickData {
    kind: 'empty' | 'uniform' | 'mixed';
    /** Distinct IDs; index 0 is always background (ID 0). Uniform: [0, id]. */
    palette: Float64Array;
    /** Mixed only: 66³ palette indices */
    indices: Uint16Array | null;
}
/** A decoded chunk as zarrita returns it. */
export interface DecodedChunk {
    data: ArrayLike<number | bigint | boolean>;
    shape: number[];
    stride: number[];
}
/** Fetches one chunk of `array` (null: missing, read as background). */
export type ChunkGetter = (array: number, coords: number[], key: string) => Promise<DecodedChunk | null>;
/** Index of the label voxel read for each of the brick's 66 voxels along one axis; -1 outside the image. */
export declare function labelAxisMap(brick: number, scale: number, dim: number, arrayDim: number): Int32Array;
/** Chunk keys shared by all readers of a label image: array and chunk position. */
export declare function labelChunkKey(level: LabelLevelParams, cx: number, cy: number, cz: number): string;
/** Brick (bx, by, bz) of an image level, read through `getChunk`. */
export declare function assembleLabelBrick(level: LabelLevelParams, bx: number, by: number, bz: number, getChunk: ChunkGetter, signal?: AbortSignal): Promise<LabelBrickData>;
/**
 * Compress the 66³ voxels that `scan` emits (in x, y, z order) into a palette and indices.
 * Consecutive equal raw values skip the palette lookup, which covers the long runs labels have.
 */
export declare function palettize(scan: (emit: (raw: number | bigint | boolean) => void) => void): LabelBrickData;
