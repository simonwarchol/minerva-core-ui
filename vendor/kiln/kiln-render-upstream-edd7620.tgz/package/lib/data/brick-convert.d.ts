/** Source-dtype-aware conversion of raw brick bytes to the atlas texture format. */
export type SourceFormat = 'uint8' | 'uint16';
export type TargetFormat = 'r8unorm' | 'r16unorm' | 'r16float';
/** Convert raw bytes of `source` dtype to the element type the `target` texture expects. */
export declare function convertBrickBytes(raw: Uint8Array, source: SourceFormat, target: TargetFormat): Uint8Array | Uint16Array;
/** Re-view already converted bytes with the element size the conversion produced. */
export declare function brickElementView(bytes: Uint8Array, source: SourceFormat, target: TargetFormat): Uint8Array | Uint16Array;
