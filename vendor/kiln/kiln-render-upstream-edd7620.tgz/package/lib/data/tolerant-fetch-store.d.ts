/**
 * TolerantFetchStore - Zarr store that handles quirky HTTP backends.
 * Maps 403→undefined, rejects HTML 200s, retries 5xx with backoff.
 */
export {};
