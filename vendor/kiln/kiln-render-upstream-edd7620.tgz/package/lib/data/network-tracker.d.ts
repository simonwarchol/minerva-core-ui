import type { NetworkStats } from './data-provider.js';
/**
 * Fixed-capacity rolling average over the last N samples.
 * Used for per-stage pipeline timing across all data providers.
 */
export declare class RollingAvg {
    private readonly capacity;
    private samples;
    constructor(capacity?: number);
    add(value: number): void;
    get value(): number;
    get count(): number;
}
/**
 * Tracks download volume and throughput for a data provider.
 */
export declare class NetworkTracker {
    private totalBytesDownloaded;
    private requestCount;
    private recentDownloads;
    record(bytes: number, requests?: number): void;
    getStats(): NetworkStats;
}
