/**
 * OME-Zarr label images: segmentations stored as integer IDs next to the image they label
 * (`<image>/labels/<name>`), with optional per-ID colours and properties in `image-label`.
 *
 * A label image is read on the image's own level grid: alignLabelLevels() picks, for every image
 * level, the label array to read and the per-axis scale between the two, so label bricks have the
 * same addresses as image bricks whatever the label pyramid looks like (fewer or more levels,
 * labels at a coarser or finer resolution, a single scale).
 */
import { Array as ZarrArray } from 'zarrita';
import type { ArrayMetadata, AbsolutePath, DataType, Readable } from 'zarrita';
import type { SpatialOrder } from './chunk-math.js';
import type { Vec3 } from '../core/pyramid.js';
/** A colour from `image-label.colors`: the label value and its 0–255 RGBA. */
export interface LabelColor {
    value: number;
    rgba: [number, number, number, number];
}
export declare function isLabelDtype(dtype: string): boolean;
/** Label value of a stored voxel: non-positive values (and NaN) are background, floats round. */
export declare function toLabelId(raw: number | bigint | boolean): number;
/** Label image names listed by a `labels` group's attributes. */
export declare function parseLabelNames(attrs: Record<string, unknown>): string[];
/** Colours from a label image's `image-label` attributes. */
export declare function parseLabelColors(attrs: Record<string, unknown>): LabelColor[];
/** Per-ID properties from `image-label.properties` (everything but `label-value`). */
export declare function parseLabelProperties(attrs: Record<string, unknown>): Map<number, Record<string, unknown>>;
/** A readable name for a segment from its properties: the first of name, class, label, type. */
export declare function segmentName(properties: Record<string, unknown> | undefined): string | undefined;
/** One array (resolution level) of a label image, in Kiln's [x, y, z] order. */
export interface LabelArrayInfo {
    /** Path of the array within the label image group */
    path: string;
    dims: Vec3;
    /** Chunk shape as read (inner chunks of a sharded array), all dimensions and [x, y, z] */
    chunkShape: number[];
    chunks: Vec3;
    /** Physical voxel spacing and origin, when the multiscales metadata has them */
    spacing?: Vec3;
    origin?: Vec3;
    /** Zarr v3 array metadata (v2 converted), so readers build arrays without fetching it again */
    metadata: ArrayMetadata<DataType>;
}
/** Everything about a label image that reading and showing it needs. */
export interface LabelImageInfo {
    /** Display name: the label image's name in the `labels` group, or the last URL segment */
    name: string;
    dtype: string;
    arrays: LabelArrayInfo[];
    /** Array rank; the spatial axes are the last three */
    rank: number;
    spatialOrder: SpatialOrder;
    channelAxisIdx: number;
    timeAxisIdx: number;
    timepointCount: number;
    colors: LabelColor[];
    properties: Map<number, Record<string, unknown>>;
}
/** What the image provides for alignment: its level grid and level-0 placement. */
export interface ImageGeometry {
    /** Per image level: voxel dimensions and per-axis log2 downsampling relative to level 0 */
    levels: Array<{
        dims: Vec3;
        exponent: Vec3;
    }>;
    /** Level-0 physical spacing and origin, when the image has valid multiscale transforms */
    spacing?: Vec3;
    origin?: Vec3;
}
/** How one image level reads its labels: which label array, and how its voxels map onto the level. */
export interface LabelLevelParams {
    /** Index into LabelImageInfo.arrays */
    array: number;
    /** Label voxels per image-level voxel, per axis (1 = same grid, 2 = labels twice as fine) */
    scale: Vec3;
    /** Image level dimensions; voxels outside them are background */
    dims: Vec3;
    /** Label array dimensions and chunk shape */
    arrayDims: Vec3;
    chunks: Vec3;
    rank: number;
    spatialOrder: SpatialOrder;
    channelAxisIdx: number;
    channelChunkSize: number;
    timeAxisIdx: number;
    timeChunkSize: number;
}
/** Most label voxels per image voxel, per axis, read for one brick; coarser levels show no labels. */
export declare const MAX_LABEL_DOWNSAMPLE = 8;
/**
 * Check that the label image covers the image, and choose per image level the label array to
 * read: the coarsest one at least as fine as the level (exact when a level matches), else the
 * finest one (labels coarser than the level are upsampled). Levels that would read more than
 * MAX_LABEL_DOWNSAMPLE label voxels per voxel and axis get none. Throws when the label image
 * belongs to a different image. `notes` lists what users should know (shown as warnings).
 */
export declare function alignLabelLevels(image: ImageGeometry, label: LabelImageInfo): {
    levels: Array<LabelLevelParams | null>;
    notes: string[];
};
/** Reads JSON documents of a Zarr hierarchy (remote or local), absent documents as null. */
export type JsonReader = (key: string) => Promise<Record<string, unknown> | null>;
/** A JsonReader over any zarrita-style store. */
export declare function jsonReader(store: {
    get(key: AbsolutePath): Promise<Uint8Array | undefined>;
}): JsonReader;
/** Names of the label images in the `labels` group under `prefix` (the image group). */
export declare function listLabelNames(read: JsonReader, prefix?: string): Promise<string[]>;
/**
 * Read a label image's metadata from the root of `store`: multiscales, array geometry,
 * `image-label` colours and properties. Throws UnsupportedDatasetError when it isn't a label
 * image Kiln can show.
 */
export declare function readLabelImage(store: {
    get(key: AbsolutePath): Promise<Uint8Array | undefined>;
}, name: string): Promise<LabelImageInfo>;
/** zarrita arrays for a label image, built from metadata already read (no network round trips). */
export declare function labelArrays(store: Readable, info: Pick<LabelImageInfo, 'arrays'>): ZarrArray<DataType, Readable>[];
