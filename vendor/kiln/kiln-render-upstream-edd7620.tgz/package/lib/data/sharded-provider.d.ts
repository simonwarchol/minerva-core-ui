/**
 * ShardedDataProvider - Loads volume data from Kiln's native sharded format
 * (volume.json + lodN.bin + lodN_index.json) using HTTP Range requests.
 */
import type { TargetFormat } from './brick-convert.js';
import type { PyramidPolicy } from '../core/pyramid.js';
import type { DataProvider, VolumeMetadata, BrickLoadResult, BrickStats, NetworkStats, PipelineTimings } from './data-provider.js';
/** A URL holds Kiln's sharded format when it serves a volume.json. Anything else is read
 *  as OME-Zarr, with or without ".zarr" in the URL (webKnossos layers have none). */
export declare function isShardedUrl(url: string): Promise<boolean>;
/**
 * DataProvider implementation for Kiln's sharded binary format
 */
export declare class ShardedDataProvider implements DataProvider {
    private basePath;
    private rawMetadata;
    private metadata;
    private lodIndices;
    private lodIndexLoads;
    private networkTracker;
    private pool;
    private targetFormat;
    private pyramidPolicy;
    private fetchAvg;
    private assemblyAvg;
    constructor(basePath: string);
    /** Set the target texture format for brick data. Must be called before the first brick load. */
    setTargetFormat(format: TargetFormat): void;
    /**
     * Initialize the provider by loading volume.json
     */
    initialize(): Promise<VolumeMetadata>;
    /** GET a JSON document, counting it in the network stats. */
    private fetchJson;
    /**
     * Convert format-specific metadata to generic VolumeMetadata
     */
    /** Must be called before initialize(). Sharded levels are pre-baked 2:1, so both policies share one geometry. */
    setPyramidPolicy(policy: PyramidPolicy): void;
    private convertMetadata;
    /**
     * Get the loaded metadata
     */
    getMetadata(): VolumeMetadata;
    /**
     * Get brick grid for a LOD level
     */
    getBrickGrid(lod: number): [number, number, number];
    /**
     * Load the index for a LOD level
     */
    /** Loads each LOD index once; concurrent callers share the in-flight request. */
    private loadLodIndex;
    /**
     * Get brick statistics
     */
    getBrickStats(lod: number, bx: number, by: number, bz: number): Promise<BrickStats | null>;
    /**
     * Check if brick is empty
     */
    isBrickEmpty(lod: number, bx: number, by: number, bz: number, maxThreshold?: number): Promise<boolean>;
    /**
     * Load a single brick
     */
    loadBrick(lod: number, bx: number, by: number, bz: number, _channelIndex?: number, signal?: AbortSignal): Promise<BrickLoadResult | null>;
    /** 206: Content-Range must match when readable (CORS often hides it; body length is checked after).
     *  200: only acceptable if Content-Length is exactly the brick, i.e. the server ignored Range. */
    private isValidRangeResponse;
    getNetworkStats(): NetworkStats;
    getPipelineTimings(): PipelineTimings;
    /**
     * Clean up resources
     */
    dispose(): void;
}
