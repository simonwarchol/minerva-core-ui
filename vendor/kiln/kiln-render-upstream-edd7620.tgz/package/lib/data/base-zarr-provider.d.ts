/**
 * BaseZarrProvider - Shared base for OME-Zarr metadata parsing, LOD calculation,
 * and brick stats. Subclassed by ZarrDataProvider (HTTP) and LocalZarrDataProvider (FS).
 */
import type { SourceSelection, DataProvider, VolumeMetadata, BrickLoadResult, BrickStats, NetworkStats } from './data-provider.js';
import type { SpatialOrder } from './chunk-math.js';
import type { PyramidPolicy } from '../core/pyramid.js';
interface OmeTransform {
    type: string;
    scale?: number[];
    translation?: number[];
}
export declare const LEGACY_HINT = "load with pyramid \"legacy\" to fall back to the uniform 2:1 model";
/** OMERO channel window: display range (start–end) within the absolute data range (min–max). */
export type OmeroWindow = {
    start: number;
    end: number;
    min: number;
    max: number;
};
/** OME-NGFF multiscales metadata (from group attributes) */
export interface OmeMultiscales {
    axes?: unknown;
    datasets: {
        path: string;
        coordinateTransformations?: OmeTransform[];
    }[];
    coordinateTransformations?: OmeTransform[];
    name?: string;
    version?: string;
}
/** Per-LOD scale factors and chunk parameters */
export interface LodParams {
    scaleX: number;
    scaleY: number;
    scaleZ: number;
    actualDimX: number;
    actualDimY: number;
    actualDimZ: number;
    csx: number;
    csy: number;
    csz: number;
    /** Number of non-spatial prefix dims before [z, y, x] (e.g. 1 for [c, z, y, x]). */
    shapePrefixLength: number;
    /** Index of the channel axis within the full shape array (-1 if no channel axis). */
    channelAxisIdx: number;
    /** Channels stored per chunk along the channel axis (1 if none). */
    channelChunkSize: number;
    /** Fixed time selection for this provider and its workers. */
    timeAxisIdx?: number;
    timeChunkSize?: number;
    timepoint?: number;
    /** Positions of x, y, z within the last three dims; absent means the usual z, y, x. */
    spatialOrder?: SpatialOrder;
}
/**
 * Whether an OMERO window can serve as a float data range: finite, ordered and within what
 * the float16 atlas stores. Some writers put the type's limits (±3.4e38) or nothing there.
 */
export declare function usableFloatWindow(w: OmeroWindow): boolean;
/** Detect the compression codec from zarr v2 (.zarray) or v3 (zarr.json) metadata. */
export declare function detectCompression(store: {
    get: (key: any) => Promise<Uint8Array | undefined>;
}, arrayPath: string): Promise<string | undefined>;
/**
 * Abstract base class for Zarr providers
 */
export declare abstract class BaseZarrProvider implements DataProvider {
    private static readonly MAX_STATS_ENTRIES;
    protected metadata: VolumeMetadata | null;
    protected brickStatsCache: Map<string, BrickStats>;
    protected pyramidPolicy: PyramidPolicy;
    /** Per-LOD chunk geometry from parseOmeMetadata(); subclasses assign it in initialize(). */
    protected lodParams: LodParams[];
    private networkTracker;
    private selection;
    /** OMERO windows for every source channel, before selection. */
    private sourceChannelWindows?;
    /** Before initialize(): sets the initial selection. After: switches the live metadata in
     *  place (slots, windows, timepoint) and forgets per-brick stats that belonged to the old one. */
    setSourceSelection(selection: SourceSelection): void;
    /** Resolve `selection` against the source and write the slot-dependent metadata fields. */
    private applySourceSelection;
    protected sourceChannelFor(slot: number): number;
    /** Must be called before initialize(); the policy shapes levels, brick grids and worker mappings. */
    setPyramidPolicy(policy: PyramidPolicy): void;
    abstract initialize(): Promise<VolumeMetadata>;
    abstract loadBrick(lod: number, bx: number, by: number, bz: number, channelIndex?: number, signal?: AbortSignal): Promise<BrickLoadResult | null>;
    abstract dispose(): void;
    /**
     * Get cached metadata
     */
    getMetadata(): VolumeMetadata;
    /** Number of source chunks one brick touches at this LOD (1 if geometry is unknown). */
    estimateBrickCost(lod: number, bx: number, by: number, bz: number): number;
    /**
     * Get brick grid dimensions for a LOD level
     */
    getBrickGrid(lod: number): [number, number, number];
    /**
     * Check if a brick is empty (max value below threshold)
     */
    isBrickEmpty(lod: number, bx: number, by: number, bz: number, maxThreshold?: number): Promise<boolean>;
    /**
     * Get cached brick statistics
     */
    getBrickStats(lod: number, bx: number, by: number, bz: number): Promise<BrickStats | null>;
    /**
     * The real float range is known: brick stats so far were normalised to the provisional
     * one, so they would misjudge empty bricks. Subclasses also update their workers.
     */
    setFloatRange(_min: number, _max: number): Promise<void>;
    /**
     * Get network/IO statistics
     */
    getNetworkStats(): NetworkStats;
    /**
     * Record download/read for statistics tracking
     */
    protected recordDownload(bytes: number, requests?: number): void;
    /**
     * Cache brick statistics
     */
    protected cacheBrickStats(lod: number, bx: number, by: number, bz: number, stats: BrickStats): void;
}
export {};
