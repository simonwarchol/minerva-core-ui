/**
 * FileSystemStore - Zarrita store adapter for File System Access API
 */
export declare class FileSystemStore {
    private dirHandle;
    constructor(dirHandle: FileSystemDirectoryHandle);
    get(key: string): Promise<Uint8Array | undefined>;
    has(key: string): Promise<boolean>;
}
