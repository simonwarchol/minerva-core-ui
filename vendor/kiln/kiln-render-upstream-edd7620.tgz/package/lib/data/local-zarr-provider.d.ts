/**
 * LocalZarrDataProvider - Loads OME-Zarr from local filesystem via
 * File System Access API. Runs on main thread (handles can't transfer to workers).
 */
import { BaseZarrProvider } from './base-zarr-provider.js';
import type { TargetFormat } from './brick-convert.js';
import type { VolumeMetadata, BrickLoadResult, PipelineTimings } from './data-provider.js';
export declare class LocalZarrDataProvider extends BaseZarrProvider {
    private dirHandle;
    private arrays;
    private targetFormat;
    private fetchAvg;
    private assemblyAvg;
    constructor(dirHandle: FileSystemDirectoryHandle);
    setTargetFormat(format: TargetFormat): void;
    initialize(): Promise<VolumeMetadata>;
    loadBrick(lod: number, bx: number, by: number, bz: number, channelIndex?: number): Promise<BrickLoadResult | null>;
    getPipelineTimings(): PipelineTimings;
    private assembleBrick;
    dispose(): void;
}
