/**
 * DecompressionPool - Round-robin Web Worker pool for parallel
 * gzip decompression of brick data off the main thread.
 */
import type { SourceFormat, TargetFormat } from './brick-convert.js';
export declare class DecompressionPool {
    private workers;
    private nextWorkerIndex;
    private requestId;
    private pendingRequests;
    enabled: boolean;
    private targetFormat;
    /** Target texture format for decompressed data: r8unorm, r16unorm or r16float. */
    setTargetFormat(format: TargetFormat): void;
    constructor(poolSize?: number);
    /** Decompress a gzip buffer of `sourceFormat` voxels, converted to the target format. */
    decompress(compressedData: ArrayBuffer, sourceFormat: SourceFormat): Promise<Uint8Array>;
    /**
     * Get pool statistics
     */
    getStats(): {
        workerCount: number;
        pendingRequests: number;
    };
    /**
     * Terminate all workers
     */
    terminate(): void;
}
/**
 * Get or create the global decompression pool
 */
export declare function getDecompressionPool(): DecompressionPool;
/**
 * Terminate the global decompression pool
 */
export declare function terminateDecompressionPool(): void;
