/**
 * Label worker: reads label bricks for any number of label images (sources) off the main
 * thread, with one decoded-chunk cache per worker shared by all sources. Assembly and palette
 * compression are label-assembly.ts; results are transferred zero-copy.
 */
import type { ArrayMetadata, DataType } from 'zarrita';
import type { LabelLevelParams } from './label-image.js';
export type LabelWorkerRequest = {
    type: 'addSource';
    id: number;
    source: number;
    url: string;
    arrays: Array<{
        path: string;
        metadata: ArrayMetadata<DataType>;
    }>;
} | {
    type: 'removeSource';
    id: number;
    source: number;
} | {
    type: 'load';
    id: number;
    source: number;
    level: LabelLevelParams;
    bx: number;
    by: number;
    bz: number;
} | {
    type: 'cancel';
    id: number;
};
export type LabelWorkerResponse = {
    type: 'done';
    id: number;
    error?: string;
} | {
    type: 'load';
    id: number;
    kind: 'empty' | 'uniform' | 'mixed';
    palette: ArrayBuffer;
    indices: ArrayBuffer | null;
    bytes: number;
};
