/**
 * Float16 conversion utilities — converts uint16 intensity values (0-65535)
 * to IEEE 754 half-precision for WebGPU's r16float texture format.
 */
/**
 * uint16 data on an r16float atlas is stored as `value - UINT16_FLOAT16_OFFSET`.
 * Half floats hold every integer in [-2048, 2048] exactly, so values 0–4096
 * (all of 12-bit data) survive bit-exact; above that, precision is at least that
 * of a plain value/65535 encoding. The shader maps texels back to value/65535
 * (see Renderer.texelScale/texelBias).
 */
export declare const UINT16_FLOAT16_OFFSET = 2048;
/**
 * Convert a float32 value to float16 bits (as uint16), rounding to nearest even (the IEEE
 * default). Values below 2^-14 become subnormals, values from 65520 up become infinity.
 */
export declare function float32ToFloat16Bits(f32: number): number;
/** Decode a uint16 float16 bit pattern to a JavaScript number. */
export declare function float16BitsToFloat32(bits: number): number;
/** Lazily-built LUT mapping a raw uint16 intensity to its stored r16float bit pattern. */
export declare function getUint16ToFloat16Lut(): Uint16Array;
/** Lazily-built LUT mapping every float16 bit pattern to its decoded float32 value. */
export declare function getFloat16ToFloat32Lut(): Float32Array;
/** Convert a Uint16Array (0-65535) to its stored r16float bit patterns (value - offset). */
export declare function uint16ToFloat16(uint16Data: Uint16Array): Uint16Array;
